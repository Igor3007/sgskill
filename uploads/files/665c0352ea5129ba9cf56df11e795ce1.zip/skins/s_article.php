<main>
    <div class="wrap-main">
        <div class="header-portfolio">
                <span><?=$view['title']?></span>
        </div> 
        <div class="article">
            <? while($data = mysqli_fetch_assoc($article)): ?>
            <div class="item-article">
                
                <? if(!empty($data['img'])): ?>
                <div class="img">
                    <a href="/page/<?=$data['id']?>.html" ><img src="<?=DOMAIN.$data['img']?>" alt="<?=$data['title']?>" /></a>
                </div>
                <? endif; ?>
                
            </div>
            <? endwhile; ?>
        </div>
    </div>
</main>