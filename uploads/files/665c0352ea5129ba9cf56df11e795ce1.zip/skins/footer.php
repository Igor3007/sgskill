

<h1 style="color: black; font-size: 50%">Slava Grebenkin Studio © 2010 - 2016</h1>
<div class="social">
                <span class="ic_36"><a target="_blank" href="http://vk.com/sunart" title="Вконтакте"><i class="fa fa-vk"></i></a></span>
                <span class="ic_36"><a target="_blank" href="https://instagram.com/slavagrebenkin/" title="Instagram"><i class="fa fa-instagram"></i></a></span>
                <span class="ic_36"><a target="_blank" href="https://www.facebook.com/slava.grebenkin" title="facebook"><i class="fa fa-facebook"></i></a></span>
                <span class="ic_36"><a target="_blank" href="http://slava-grebenkin.deviantart.com/" title="Deviantart"><i class="fa fa-deviantart"></i></a></span>
                <span class="ic_36"><a target="_blank" href="http://www.weibo.com/slavagrebenkin" title="weibo.com"><i class="fa fa-weibo"></i></a></span>
                <span class="ic_36"><a target="_blank" href="https://500px.com/Slava_Grebenkin" title="500px"><i class="fa fa-500px"></i></a></span>
</div>
