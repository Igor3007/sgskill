<main>
    <div class="wrap-main">
    	<div class="item-portfolio">
            <div class="header-portfolio">
                <span><?=$data['masterTitle']?></span>
            </div>
            <div class="specialist-info">
            	<div class="sp-avatar">
            	    <img src="<?=DOMAIN.$data['img']?>" alt="<?=$data['masterTitle']?>" />
            	</div>
                <article>
                   <?$text = htmlspecialchars_decode($data['text']); 
                  $regx = "/\{gallery_([0-9]+)\}/i";
                  echo preg_replace_callback($regx, "getGalleryPreg", $text);?> 
                </article>
                        
            </div>
            </div>
        </div>
        <div class="item-portfolio contacts">
            <div class="header-portfolio">
                <span>Связаться</span>
            </div>
            <div class="contacts-specialist">
            	<div class="form" >
            		<form id="form-contacts" action="#" method="post" onsubmit="return false" >
            			<p>
            				<span class="ic_24 fa fa-user" ></span><input type="text" name="name" placeholder="Ваше имя" />
            				<span class="ic_24 fa fa-phone" ></span><input type="phone" name="phone" placeholder="Номер телефона" />
            			</p>
            			<p>
            				<span class="ic_24 fa fa-link" ></span><input type="text" name="profile" placeholder="Профиль в соцсети" />
            				<span class="ic_24 fa fa-calendar" ></span><input type="text" name="date" id="calendar" placeholder="Дата мероприятия" />
            			</p>
            			<p class="submit"><button data-id="<?=$data['masterId']?>" id="send-contacts">Отправить</button></p>
                        <div class="err"></div>
            		</form>
            	</div>
            	<div class="info" >
            		<p>Связаться со специалистом</p>
            		Для связи со специалистом заполните все поля формы и нажмите отправить. Специалисту отправятся все ваши контакты и он свяжется с вами в самое ближайшее время =) 
            	</div>
            </div>
        </div> 
    </div>
</main>