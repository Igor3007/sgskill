<main>
    <div class="wrap-main">
        <div class="header-portfolio">
                <span><?=$data['title']?></span>
        </div> 
        <div class="about">
            <? if(!empty($data['password']) && $_COOKIE['page_'.$data[id]] != md5($data['password'])): ?>
                <div class="form_password" >
                    <div class="box-text">Для доступа к странице введите пароль</div>
                    <p><input id="pass_input" class="input" type="text" placeholder="Введите пароль" /></p>
                    <button class="btn-grey" id="check_pass" data-id="<?=$data['id']?>">Готово</button>
                    <div class="err"></div>
                </div>
                <? exit(); ?>
            <? endif; ?>
            <? if(!empty($data['img']) && $data['cat'] != 2): ?>
                <div class="foto-autor foto-page">
                    <img src="<?=$data['img']?>" alt="" />
                </div>
            <? endif; ?>
           <div class="descrt page"><?
            $text = htmlspecialchars_decode($data['text']);
            $regx = "/\{gallery_([0-9]+)\}/i";
            echo preg_replace_callback($regx, "getGalleryPreg", $text);
            ?></div>
        </div>
    </div>
</main>