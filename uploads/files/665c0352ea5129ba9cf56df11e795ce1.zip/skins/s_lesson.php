<main>
            <div class="wrap-main">
                <div class="header-portfolio">
                    <span>Обучение</span>
                </div>
                
                <div class="box-lesson">
                    <div class="left-img">
                        <img src="<?=$data['img']?>" alt="" />
                    </div>
                    <div class="right-detalis">
                        <div class="lesson-detalis">
                            <ul><h1><?=$data['masterTitle']?></h1>
                                <? if($data['date']): ?>
                                <li class="lesson-date"><span class="calendar"></span><?=setDates($data['date'], array(true, false))?></li>
                                <li class="weekday"><?=setDates($data['date'], array(false, true))?></li>    
                                <? endif; ?>
                                
                                <li class="lesson-time"><span class="ic_24 fa fa-clock-o time"></span><?=$data['mc_time']?></li>
                                <li class="lesson-time map"><span class="ic_24 fa fa-map-marker location"></span><a target="_blank" href="<?=urldecode($data['adress_link'])?>"><?=$data['adress']?></a></li>
                                <li class="lesson-time"><span class="ic_24 prise fa fa-rub"></span><?=$data['price']?></li>
                                <?=(!empty($data['group']) ?      '<li class="lesson-time"><span class="ic_24 group fa fa-users"></span>'.$data['group'].'</li>' : '') ?>
                                <?=(!empty($data['group_plus']) ? '<li class="lesson-time"><span class="ic_24 group-plus fa fa-user-plus"></span>'.$data['group_plus'].'</li>' : '') ?>
                                
                                
                                
                            </ul>
                        </div>
                        <div class="full_text" onload="loadText()">
                           <?=$data['pre_text']?>
                        </div> 
                        
                    </div>
                 <div class="full_text_1">
                 <?$text = htmlspecialchars_decode($data['text']);
                    $regx = "/\{gallery_([0-9]+)\}/i";
                    echo preg_replace_callback($regx, "getGalleryPreg", $text);?></div>    
                </div>
               
                <div class="box-comment">
                    <div class="header-comment">Отзывы</div>
                    
                    <? if(!isset($_SESSION[user][uid])): ?>
                    <div class="box-auth">
                        <p><span>Войти</span>
                            <a title="Вконтакте" href="<?=DOMAIN?>inc/oAuth.php?auth=vk&r=<?=$_GET[id]?>"><span class="ic_36"><i class="fa fa-vk"></i></span></a>
                            <a title="Facebook"href="<?=DOMAIN?>inc/oAuth.php?auth=facebook&r=<?=$_GET[id]?>"><span class="ic_36"><i class="fa fa-facebook"></i></span></a>    
                        </p>
                    </div>
                    <? endif; ?>
                    
                    <?=(!mysqli_num_rows($getComments) && !$_SESSION[user][uid] ? '<div class="no_comm_status">К данному уроку пока нет комментариев </div>' : '')?>
                    <div class="wrap-comment">
                    <?php while($data = mysqli_fetch_assoc($getComments)): ?>
                    
                        <div class="item-comment">
                           <div class="comment-ava">
                             <a target="_blank" href="<?=($data[auth_id] == 'vk' ? 'http://vk.com/id'.$data[uid] : 'https://www.facebook.com/app_scoped_user_id/'.$data[uid].'/')?>"><img src="<?=$data[avatar]?>" alt=""></a>
                           </div>
                           <div class="text-comment">
                             <h5 title="" ><a target="_blank" href="<?=($data[auth_id] == 'vk' ? 'http://vk.com/id'.$data[uid] : 'https://www.facebook.com/app_scoped_user_id/'.$data[uid].'/')?>"><?=$data[user]?></a></h5>
                             <div class="this-text"><?=$data[text_comment]?></div>
                           </div>
                           <div class="date-comment"><?=($_SESSION[user][uid] ? '<span class="response-user">Ответить</span>':'')?> <span class="date"><?=getDates($data[date_comment])?></span></div>
                        </div>
                    <? endwhile; ?>
                    </div>
                </div>
                
                <? if(isset($_SESSION[user][uid]) && !empty($_SESSION[user][uid])): ?>
                        <div class="send-comment-box">
                           <div class="item-comment">
                              <div class="comment-ava">
                                <img src="<?=$_SESSION[user][avatar]?>" alt="<?=$_SESSION[user][name]?>">
                              </div>
                              <div class="text-comment">
                                <? if(!blackListUser($_SESSION[user][uid])):?>
                                  <textarea placeholder="Ваш комментарий..." id=comment></textarea>
                                <div class="submit-button">
                                    <button id="add_comment" data-id="<?=$_GET[id]?>" class="btn-grey">Добавить</button>
                                </div> 
                                <? else: ?>
                                  <span class ="blist" >Ваш аккаун добавлен в черный список, вы можете оставлять комментарии</span>
                                <? endif; ?>  
                              </div>
                           </div>
                        </div>
                <? endif; ?>
            </div>
        </main>