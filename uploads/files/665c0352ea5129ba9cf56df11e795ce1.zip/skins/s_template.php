<?
$message = '
        <div><center><b>У ВАС НОВЫЙ ЗАКАЗ НА САЙТЕ SG-WEDDING.RU</b></center></div><br />
        <table>
            '.($dataSpecialist['masterTitle']  ? '<tr><td><b>Специалист:</b><td>     <td><a href="http://sg-wedding.ru/specialist/'.$dataSpecialist['masterId'].'.html">'.$dataSpecialist['masterTitle'].'</a></td></tr>' : '').'
            '.($params['user_data']  ? '<tr><td><b>ФИО клиента:</b><td>     <td>'.$params['user_data'].'</td></tr>' : '').'
            '.($params['user_phone'] ? '<tr><td><b>Телефон:</b><td>   <td>'.$params['user_phone'].'</td></tr>' : '').'
            '.($params['user_select_wedding']  ? '<tr><td><b>Профиль в соцсети:</b><td> <td>'.$params['user_select_wedding'].'</td></tr>' : '').'
            '.($params['tour_start_date']  ? '<tr><td><b>Дата:</b><td> <td>'.$params['tour_start_date'].'</td></tr>' : '').'
        </table>
        <br />
        <hr />
        <div>Поздравляем! В случае заключения договора просьба сразу об этом сообщить и не забудьте вести ваш календать! <br />
             После '.$params['tour_start_date'].' мы связываемся с молодоженами для получения отзыва по работе =) Удачи =)<br />
            <a href="http://sg-wedding.ru">sg-wedding.ru</a>
        </div>
    ';
?>