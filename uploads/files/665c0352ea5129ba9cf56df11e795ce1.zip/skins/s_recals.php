<main>
    <div class="wrap-main">
         
        <div class="header-portfolio">
                <span><?=$dataPage['title']?></span>
        </div>
        <div class="about">
           <div class="descrt page">
           <?$text = htmlspecialchars_decode($dataPage['text']);
            $regx = "/\{gallery_([0-9]+)\}/i";
            echo preg_replace_callback($regx, "getGalleryPreg", $text);?></div>
        </div>
     
        
        <div class="item-portfolio">
            <div class="header-portfolio">
                <span>Отзывы после обучения</span>
            </div>
            <div class="box-recals">        
            <? while($dataRecal = mysqli_fetch_assoc($recals)): ?>        
                <div class="item-recal">
                    <div class="recal-text animated">
                        <div class="this"><?=stripslashes($dataRecal['text'])?></div>
                        <span class="stick"></span>
                    </div>
                    <div class="user-avatar">
                        <img src="<?=$dataRecal['img']?>" alt="<?=$dataRecal['title']?>" />
                    </div>
                    <h5><a href="<?=htmlspecialchars_decode(urldecode($dataRecal['link']))?> " target = "_blank"><?=stripslashes($dataRecal['title'])?></a></h5>
                </div>
            <? endwhile ?>            
            </div>
        </div>
    </div>
</main>