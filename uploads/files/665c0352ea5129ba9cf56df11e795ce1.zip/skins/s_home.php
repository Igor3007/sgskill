<main>
    <div class="wrap-main">
      <? while($data = mysqli_fetch_assoc($query)): ?>
        <div class="item-portfolio">
            <div class="header-portfolio">
                <span><?=$data['title']?></span>
            </div>
            <div class="gallery-portfolio">
                <div class="wrap-gallery">
                    <? $img = getGalleryPortfolio($data['id']); ?>
                    <? while($value = mysqli_fetch_assoc($img)): ?>
                        <div class="item-foto"> <a href="./img/gallery/<?=$value['img']?>"> <img src="./img/gallery/min/<?=$value['img']?>" alt="<?=$data['title']?> Слава Гребенкин" /></a> </div>
                    <? endwhile; ?>
                </div>
            </div>
        </div>
    <? endwhile ?>
    </div>
</main>