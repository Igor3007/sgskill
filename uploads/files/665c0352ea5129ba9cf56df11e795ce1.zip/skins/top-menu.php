<ul class="nav-bar">
    <div class="m-left">
       <div class="wrap">
            <li class="item-menu"><a href="<?=DOMAIN?>article.html">Статьи</a></li>
            <li class="item-menu"><a href="<?=DOMAIN?>specialists.html">Специалисты</a></li>
       </div>    
    </div>
    <div class="m-mid">
         <li><a href="/">
        <p class="logo">Все для свадьбы</p>
        <p class="sl">Проект Славы Гребенкина</p>
    </a></li>
    </div>
    <div class="m-right">
        <div class="wrap">
            <li class="item-menu"><a href="<?=DOMAIN?>partners.html">Партнеры</a></li>
            <li class="item-menu"><a href="<?=DOMAIN?>contacts.html">Контакты</a></li>
        </div>
    </div>
</ul>