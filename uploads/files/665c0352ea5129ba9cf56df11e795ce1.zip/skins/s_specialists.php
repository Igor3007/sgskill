<main>
    <div class="wrap-main">
        <? while($cat = mysqli_fetch_assoc($catid)): ?>
        <div class="item-portfolio">
            <div class="header-portfolio">
                <span><?=$cat['title']?></span>
            </div>
            <div class="box-specialist"> 
                <? $dataMaster = getMasterClassList(array('where' => 'catid = '.$cat[id].' AND status=1'));
                     while($data = mysqli_fetch_assoc($dataMaster)): ?>
                    <div class="item-specialist">
                        <div class="user-avatar">
                            <a href="/specialist/<?=$data['masterID']?>.html"><a href="/specialist/<?=$data['masterID']?>.html"><img class="sp-img" src="<?=DOMAIN.$data['img']?>" alt="<?=$data['title']?>" /></a></a>
                        </div>
                        <h5><a href="/specialist/<?=$data['masterID']?>.html" target = "_blank"><?=$data['title']?></a></h5>
                    </div>
                <? endwhile ?>
            </div>
        </div>
    <? endwhile ?>   
    </div>
</main>