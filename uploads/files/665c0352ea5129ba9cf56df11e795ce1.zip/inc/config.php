<?php
/* === Подключение к базе данных === */

$hostname = "localhost";        //хост
$db_username = "root";          //Пользователь
$db_password = "";              //Пароль
$db_name = "sg_portfolio";      //База

$id_db = mysqli_connect($hostname, $db_username, $db_password, $db_name);
         mysqli_set_charset($id_db, 'UTF8');
        
        if(mysqli_connect_errno()){
            printf("Failed connect database: %s\n",  mysqli_connect_error());
}

/* === Настройки доступа к сайту === */
    define('ACCESS_KEY', 'qwe');  //ключ доступа к панели управления
    define('CP_ADMIN_PASSWORD', 'Vjcrdf');  //Пароль от админки
    define('FOLDER', '');
    define('DOMAIN', 'http://'.$_SERVER[SERVER_NAME].'/'.FOLDER);
 
/* === Настройки админ панели === */
    define('COUNT_ITEM_PG', '15');

/* === Настройки почтового робота === */
    
    // кому отправляем(Имя, email)
    DEFINE('SENDER_NAME', 'specialist'); 
    DEFINE('EMAIL_ADDRESS', 'dok307@gmail.com'); //на этот ящик приходят уведомления

    // от кого отправляем
    DEFINE('FROM_NAME', 'SG-WEDDING');
    DEFINE('FROM_EMAIL', 'notific@sg-wedding.ru');

 
?>