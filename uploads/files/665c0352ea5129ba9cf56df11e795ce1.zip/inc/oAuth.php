<?php session_start();
include('config.php');
include('../core/model.php');
if(isset($_GET[r])){ $_SESSION[redirect] = $_GET[r]; }

define('VK_REDIRECT_URI', DOMAIN.'inc/oAuth.php?provider=vk');
define('FB_REDIRECT_URI', DOMAIN.'inc/oAuth.php?provider=facebook');



if(isset($_GET[auth]) && !isset($_SESSION[uid])){

  if($_GET[auth] == "facebook"){
    $url = 'https://www.facebook.com/dialog/oauth';
      
    $params = array(
       'client_id'     => FB_CLIENT_ID,
       'redirect_uri'  => FB_REDIRECT_URI,
       'response_type' => 'code',
       'scope'         => 'email,user_birthday'
    );

    header('location:' . $url . '?' . urldecode(http_build_query($params)) . '');
    }
}
if (isset($_GET['code']) && $_GET[provider] == 'facebook') {
   $params = array(
        'client_id'     => FB_CLIENT_ID,
        'redirect_uri'  => FB_REDIRECT_URI,
        'client_secret' => FB_CLIENT_SECRET,
        'code'          => $_GET['code']
    );

    $url = 'https://graph.facebook.com/oauth/access_token';

    $tokenInfo = null;
    parse_str(file_get_contents($url . '?' . http_build_query($params)), $tokenInfo);

    if (count($tokenInfo) > 0 && isset($tokenInfo['access_token'])) {
        $params = array(
            'fields' => 'id,name,link,first_name,last_name',
            'access_token' => $tokenInfo['access_token']);

        $userInfo = json_decode(file_get_contents('https://graph.facebook.com/me' . '?' . urldecode(http_build_query($params))), true);

        if (isset($userInfo['id'])) {
            $userInfo = $userInfo;
            $result = true;
        }
    }
}
    
    if ($result){
        $userData = array();
            $userData['uid'] = $userInfo['id']; //id 
            $userData['first_name'] = $userInfo['first_name']; //имя пользователя
            $userData['last_name'] = $userInfo['last_name']; //фамилия
            $userData['link'] = $userInfo['link']; //ссылка на профиль
            $userData['avatar'] = 'http://graph.facebook.com/'.$userInfo['id'].'/picture?type=large';
            $userData['auth_id'] = $_GET['provider'];
        
        if(!getIssetUser($userData['uid'])){
            $setUserData = setAddUser($userData);
            if($setUserData['status']){
                header("Location: ../lesson/$_SESSION[redirect].html");
                session_write_close();
                exit();
            }else{
                exit($setUserData['msg']);
            }
        }else{
            setUpdateUser($userData);
            header("Location: ../lesson/$_SESSION[redirect].html");
            session_write_close();
            exit();
        }
    }
    
/*==========================vkontakte==============================*/
if(isset($_GET[auth]) && !isset($_SESSION[uid])){
  if($_GET[auth] == "vk"){    
    $url = 'http://oauth.vk.com/authorize';

    $params = array(
        'client_id'     => CLIENT_ID,
        'redirect_uri'  => VK_REDIRECT_URI,
        'response_type' => 'code'
        
    );

    header('location:' . $url . '?' . urldecode(http_build_query($params)) . '');
    }
}


if (isset($_GET['code']) && $_GET[provider] == 'vk') {
    
    $params = array(
        'client_id' => CLIENT_ID,
        'client_secret' => CLIENT_SECRET,
        'code' => $_GET['code'],
        'redirect_uri' => VK_REDIRECT_URI
    );

    $token = json_decode(file_get_contents('https://oauth.vk.com/access_token' . '?' . urldecode(http_build_query($params))), true);
    
    if (isset($token['access_token'])) {
        $params = array(
            'uids'         => $token['user_id'],
            'fields'       => 'uid,first_name,last_name,screen_name,sex,last_name,photo_100',
            'access_token' => $token['access_token']
        );
        
      $userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get' . '?' . urldecode(http_build_query($params))), true);
        if (isset($userInfo['response'][0]['uid'])) {
            $userInfo = $userInfo['response'][0];
            $result = true;
        }
    }
    if($result){
        $userData = array();
            $userData['uid'] = $userInfo['uid']; //id 
            $userData['first_name'] = $userInfo['first_name']; //имя пользователя
            $userData['last_name'] = $userInfo['last_name']; //фамилия
            $userData['link'] = 'http://vk.com/'.$userInfo['screen_name']; //ссылка на профиль
            $userData['avatar'] = $userInfo['photo_100'];
            $userData['auth_id'] = $_GET['provider'];
        
        if(!getIssetUser($userData['uid'])){
            $setUserData = setAddUser($userData);
            if($setUserData['status']){
                header("Location: ../lesson/$_SESSION[redirect].html");
                session_write_close();
                exit();
            }else{
                exit($setUserData['msg']);
            }
        }else{
            setUpdateUser($userData);
            header("Location: ../lesson/$_SESSION[redirect].html");
            session_write_close();
            exit();
        }
        
       
    }
}


?>