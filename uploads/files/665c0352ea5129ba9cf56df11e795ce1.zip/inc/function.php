<?php
/*DEFINE("ACCESS", "");

if(!defined("ACCESS")) {exit('error: not access function'); }*/

/*===Постраничная навигация===*/

function pagination($num, $table, $page_link, $where_id){
include('config.php');
    if($where_id){
        $where = 'WHERE'.$where_id;
    }

$page_num_count = mysqli_query($id_db, "SELECT * FROM `$table` $where") or die(mysql_error());
$page = $_GET['page'];
$posts = mysqli_num_rows($page_num_count);
$total = intval(($posts - 1) / $num) + 1;
$page = intval($page);
    if(empty($page) or $page < 0) $page = 1;
    if($page > $total) $page = $total;
        $start = $page * $num - $num; 
    if ($page != 1) $pervpage = '<a class = "page_back" href= '.$page_link.'page='. ($page - 1) .'> < Предыдущая </a>';
								
    if ($page != $total) $nextpage = ' <a class = "page_next" href='.$page_link.'page='. ($page + 1) .'>Следующая > </a>';
    if($page - 2 > 0) $page2left = '<a href= '.$page_link.'page='. ($page - 2) .'>'. ($page - 2) .'</a>';
    if($page - 1 > 0) $page1left = '<a href= '.$page_link.'page='. ($page - 1) .'>'. ($page - 1) .'</a>';
    if($page + 2 <= $total) $page2right = '<a href= '.$page_link.'page='. ($page + 2) .'>'. ($page + 2) .'</a>';
    if($page + 1 <= $total) $page1right = '<a href= '.$page_link.'page='. ($page + 1) .'>'. ($page + 1) .'</a>';

    return array('start'  => $start, 
                 'button' => '<div class = nav_button> '.$pervpage.$page2left.$page1left.'<a class = page_act>'.$page.'</a>'.$page1right.$page2right.$nextpage.'</div>',
                 'end'    => $num
    );
       
}

/*=== Очистка каталога на сервере ===*/    //проверить сессию
function clearTemp($url) {
if (file_exists($url))
   foreach (glob($url.'*') as $file)
      unlink($file);
}

/*Активный пункт selecta*/
$status = array(
    '0' =>  'Заблокирован',
    '1' =>  'Разблокирован'
);

function selectActive($array, $id){
    $arr = "";
    foreach($array AS $key => $value){
        if($key == $id){
            $arr .= '<option value="'.$key.'" selected="selected" >'.$value.'</option>'; 
        }else{
            $arr .= '<option value="'.$key.'" >'.$value.'</option>'; 
        }
    }
    
    return $arr;
}

 
/*=== Перемещение файла из временного каталога ===*/
function copyFiles($from, $to){
    $filename = basename($from);
    $uploadDir = $_SERVER['DOCUMENT_ROOT'].$to.$filename;
    $from = $_SERVER['DOCUMENT_ROOT'].$from;
    
    if(!is_dir($_SERVER['DOCUMENT_ROOT'].$to) or !is_file($from)){
        return array('status' => false, 'err' => 'error: не существует файл или каталог'); 
    }
    
    if(copy($from, $uploadDir)){
        return array('status' => true, 'url' => $to.$filename); 
    }else{
        return array('status' => false); 
    }
}

/*=== Удаление файла с сервера ===*/
function deleteFile($params){
    $file = $_SERVER['DOCUMENT_ROOT'].$params['file'];
    
    if (file_exists($file)){
       $delete = unlink($file);
    }else{
      return array('status' => false, 'err' => 'Ошибка: Не найден файл или каталог');
    }
      
    if($delete){
       return array('status' => true); 
    }else{
       return array('status' => false, 'err' => 'Ошибка: Не удалось удалить файл');
    }
    
}

/*=== Удаление нескольких файлов ===*/

function deleteFiles($array){
    $url     = $_SERVER['DOCUMENT_ROOT'].'/img/gallery/';
    $url_min = $_SERVER['DOCUMENT_ROOT'].'/img/gallery/min/';
    
    foreach($array AS $file){
       if (file_exists($url.$file[0])){
            $delete = unlink($url.$file[0]);
        }
        
        if (file_exists($url_min.$file[0])){
            $delete = unlink($url_min.$file[0]);
        }
    }
       
}

/*===Текущая дата в формате 'Число Месяц Год День недели'===*/

function setDates($date, $set){
    
    $month = array(
        01 => 'Явавря',
        02 => 'Февраля',
        03 => 'Марта',
        04 => 'Апреля',
        05 => 'Мая',
        06 => 'Июня',
        07 => 'Июля',
        08 => 'Августа',
        09 => 'Сентября',
        10 => 'Октября',
        11 => 'Ноября',
        12 => 'Декабря'
    );
    
    $weekday = array(
        1 => 'Понедельник',
        2 => 'Вторник',
        3 => 'Среда',
        4 => 'Четверг',
        5 => 'Пятница',
        6 => 'Суббота',
        7 => 'Воскресенье'
    );
    $arrDates = explode(' ', $date);
    $date = explode('-', $arrDates[0]); 
    $time = explode(':', $arrDates[1]); 
    
    if($set[0]){
        $return .= '<span class="set_day">'.$date[2].'</span> <span class="set_month">'.$month[$date[1]].'</span> <span class="set_year">'.$date[0].'</span>'; 
    }
    
    if($set[1]){
        $return .= '<span class="set_week">'.$weekday[date("w", mktime(0, 0, 0, $date[1], $date[2], $date[0]))].'</span>';
    }
    
    return  $return;
    
}


/*=== Преобразовывает дату типа TIME STAMP в удобный вид ===*/

function getDates($value, $time_zone = 0){        
                $montharray = array('1' => 'Января', '01' => 'Января',
				                    '2' => 'Февраля', '02' => 'Февраля',
									'3' => 'Марта', '03' => 'Марта',
									'4' => 'Апреля', '04' => 'Апреля',
									'5' => 'Мая', '05' => 'Мая',
									'6' => 'Июня', '06' => 'Июня',
									'7' => 'Июля', '07' => 'Июля',
									'8' => 'Августа', '08' => 'Августа',
									'9' => 'Сентября', '09' => 'Сентября',
									'10' => 'Октября', 
									'11' => 'Ноября', 
									'12' => 'Декабря');
                $dayarray = array(   '01' => '1', '11' => '11', '21' => '21', '31' => '31',
				                     '02' => '2', '12' => '12', '22' => '22',
									 '03' => '3', '13' => '13', '23' => '23',
									 '04' => '4', '14' => '14', '24' => '24',
									 '05' => '5', '15' => '15', '25' => '25',
									 '06' => '6', '16' => '16', '26' => '26',
									 '07' => '7', '17' => '17', '27' => '27',
									 '08' => '8', '18' => '18', '28' => '28',
									 '09' => '9', '19' => '19', '29' => '29',
									 '10' => '10', '20' => '20', '30' => '30',); 									
                $time = explode(' ',$value);
				
                $date = $time[0];
				        
                        $dateconvert = explode('-',$date);
                        $year  = $dateconvert[0];
                        $month = $montharray[($dateconvert[1])];
                        $day   = $dayarray[($dateconvert[2])];
               $timesec = explode(':',$time[1]);
    
               $timesec[0] = $timesec[0] + $time_zone;
               if($timesec[0] >= 24) $timesec[0] = $timesec[0] - 24;
    
               //return $time_hour;
    
			   $current_time = mktime ( date("H"), date("i"), date("s"), date("n"), date("j"), date("Y"), -1  );
			   $countSec = $current_time - mktime($timesec[0], $timesec[1], $timesec[2], $dateconvert[1], $dateconvert[2], $dateconvert[0]);
			   $min = array('0' => 'минут', '1' => 'минуту', 
			                '2' => 'минуты', '3' => 'минуты', 
							'4' => 'минуты', '5' => 'минут', 
							'6' => 'минут', '7' => 'минут', 
							'8' => 'минут', '9' => 'минут');				   
                $hr = array('0' => 'часов', '1' => 'час', 
			                '2' => 'часа', '3' => 'часа', 
						    '4' => 'часа', '5' => 'часов', 
						    '6' => 'часов', '7' => 'часов', 
						    '8' => 'часов', '9' => 'часов');
				$b= floor($countSec / 60);			
				if ( $b == 11 || $b == 12 || $b == 13 || $b == 14){$b = 0;}	
				$b = substr($b, -1 );
				$times = floor($countSec / 60)." $min[$b] назад";
				if ($times == 0){$times = "меньше минуты";}
				if($times > 60){
                                $c = floor($times / 60);		
				if ( $c == 11 || $c == 12 || $c == 13 || $c == 14){$c = 0;}
                $c = substr($c, -1 );
                $times = floor($times / 60)." $hr[$c] назад";  }
				 $ccc = date("j");
				 if($times < 24 and $ccc <= $dateconvert[2]){
				                  return  "сегодня в ".$timesec[0].":".$timesec[1] ;
				 }
				 else{  $ccc = $ccc - 1;
				        if ($times < 48 and $ccc == $dateconvert[2]){
				                          return "вчера в ".$timesec[0].":".$timesec[1] ;}
				        else{  
				             if ($year == date(Y)){ unset($year); }
                             return $day." ".$month." ".$year." ".в." ".$timesec[0].":".$timesec[1]; }
					   }}

/*=== Отправка уведомлений на почту администратора ===*/

function send_notification($address, $message) {   
require_once("lib/class.phpmailer.php");    

$mail             = new PHPMailer();
$mail->SMTPAuth   = true;                   
$mail->Host       = "smtp.yandex.ru";       // SMTP server почтового сервиса
$mail->Port       = 465;                    // set the SMTP port 
$mail->Username   = "angy-tour";                // Логин от почты
$mail->Password   = "DcT5RjpkS6";             // Пароль от почты
$mail->SMTPDebug  = 2;
$mail->SetFrom(FROM_EMAIL, FROM_NAME);
$mail->CharSet='utf-8';                     
$mail->Subject    = "Новый заказ на сайте";
$mail->MsgHTML($message);
$mail->AddAddress($address, SENDER_NAME);

if(!$mail->Send()) { 
        return 'error notification:'.$mail->ErrorInfo; 
    }else{
        $mail->ClearAddresses();
        $mail->ClearAttachments();
        $mail->IsHTML(false);
    return true;
    }
      
}



/*=== Обрезка строки до N симвлов ===*/
function crop_str($string, $limit, $after = '...')
{
 
 if (strlen($string) > $limit) {
 $substring_limited = substr($string, 0, $limit); 
 $return = substr($substring_limited, 0, strrpos($substring_limited, ' ')) . $after;
  return $return;
 } else{
      return $string;
 }


}


function setChangeDate($date_add, $date_change){
    $date_change_print = $date_change;
    $date_add = explode(' ', $date_add);
    $dateArr = explode('-', $date_add[0]);
    $timeArr = explode(':', $date_add[1]);
    $date_add =  mktime ( $timeArr[0], $timeArr[1], 0, $dateArr[1], $dateArr[2], $dateArr[0] );
    
    $dateArr_2 = explode('-', $date_change);
    $date_change =  mktime ( 0, 0, 0, $dateArr_2[1], $dateArr_2[0], $dateArr_2[2] );
    
    if($date_add > $date_change){
        return '<span style="color:red;">'.$date_change_print.'</span>';
    }else{
        return '<span style="color:green;">'.$date_change_print.'</span>';
    }
}


/*=== Простая валидация входящих данных ===*/
function validate($type_validate, $data, $params = false){
    $data = addslashes($data);
    
    switch($type_validate){
        case 'text': //русского и латинского алфавита, знака "_" (подчерк), пробела и цифр:
            $data = filter_var($data, FILTER_SANITIZE_STRING);
            $data = filter_var($data, FILTER_SANITIZE_SPECIAL_CHARS);
            $data = preg_replace('/[^(\w)|(\x7F-\xFF)|(\s)|(\.\,\-\!\?\%\#)]/', '', $data);
            
              return $data;
           
        break;
        
        case 'int':
            $data = filter_var($data, FILTER_SANITIZE_NUMBER_INT);
            
            if($params){
                $params = explode(':', $params);
                $min = $params[0];   $max = $params[1];
                
            $filter = filter_var($data, FILTER_VALIDATE_INT,
                            array('options' => array('min_range' => $min, 'max_range' => $max)));
            if($filter){
                return $data;
            }else{
                return exit('error validate 2: not validate int');    
            }
            }else{
            return $data;    
            }
        
            
        break;
        
        case 'email':
        $data = filter_var($data, FILTER_SANITIZE_EMAIL);
        if(filter_var($data, FILTER_VALIDATE_EMAIL)){
            return $data;
        }else{
            return exit('error validate 3: not validate email');
        }
        break;
            
        case 'special_chars':
        
            $data = filter_var($data, FILTER_SANITIZE_SPECIAL_CHARS);
            return $data;
            
        break;    
        
        default: exit('error validate: no correct type data for validate');
    }
}

/*==== Обрезка и масштабирование изображений ====*/
function resize($file_input, $file_output, $w_o, $h_o, $percent = false) {
	list($w_i, $h_i, $type) = getimagesize($file_input);
	if (!$w_i || !$h_i) {
		echo 'Невозможно получить длину и ширину изображения';
		return;
    }
    $types = array('','gif','jpeg','png');
    $ext = $types[$type];
    if ($ext) {
    	$func = 'imagecreatefrom'.$ext;
    	$img = $func($file_input);
    } else {
    	echo 'Некорректный формат файла';
		return;
    }
	if ($percent) {
		$w_o *= $w_i / 100;
		$h_o *= $h_i / 100;
	}
	if (!$h_o) $h_o = $w_o/($w_i/$h_i);
	if (!$w_o) $w_o = $h_o/($h_i/$w_i);
	$img_o = imagecreatetruecolor($w_o, $h_o);
	imagecopyresampled($img_o, $img, 0, 0, 0, 0, $w_o, $h_o, $w_i, $h_i);
	if ($type == 2) {
		return imagejpeg($img_o,$file_output,100);
	} else {
		$func = 'image'.$ext;
		return $func($img_o,$file_output);
	}
}


function crop($file_input, $file_output, $crop = 'square',$percent = false) {
	list($w_i, $h_i, $type) = getimagesize($file_input);
	if (!$w_i || !$h_i) {
		echo 'Невозможно получить длину и ширину изображения';
		return;
    }
    $types = array('','gif','jpeg','png');
    $ext = $types[$type];
    if ($ext) {
    	$func = 'imagecreatefrom'.$ext;
    	$img = $func($file_input);
    } else {
    	echo 'Некорректный формат файла';
		return;
    }
	if ($crop == 'square') {
		$min = $w_i;
		if ($w_i > $h_i) $min = $h_i;
		$w_o = $h_o = $min;
	} else {
		list($x_o, $y_o, $w_o, $h_o) = $crop;
		if ($percent) {
			$w_o *= $w_i / 100;
			$h_o *= $h_i / 100;
			$x_o *= $w_i / 100;
			$y_o *= $h_i / 100;
		}
    	if ($w_o < 0) $w_o += $w_i;
	    $w_o -= $x_o;
	   	if ($h_o < 0) $h_o += $h_i;
		$h_o -= $y_o;
	}
	$img_o = imagecreatetruecolor($w_o, $h_o);
	imagecopy($img_o, $img, 0, 0, $x_o, $y_o, $w_o, $h_o);
	if ($type == 2) {
		return imagejpeg($img_o,$file_output,100);
	} else {
		$func = 'image'.$ext;
		return $func($img_o,$file_output);
	}
}

/*=== обрезка с сохранением пропорций ===*/

  function crop_prop($image, $save, $x_o, $y_o, $w_o, $h_o) {
    if (($x_o < 0) || ($y_o < 0) || ($w_o < 0) || ($h_o < 0)) {
      echo "Некорректные входные параметры";
      return false;
    }
    list($w_i, $h_i, $type) = getimagesize($image); // Получаем размеры и тип изображения (число)
    $types = array("", "gif", "jpeg", "png"); // Массив с типами изображений
    $ext = $types[$type]; // Зная "числовой" тип изображения, узнаём название типа
    if ($ext) {
      $func = 'imagecreatefrom'.$ext; // Получаем название функции, соответствующую типу, для создания изображения
      $img_i = $func($image); // Создаём дескриптор для работы с исходным изображением
    } else {
      echo 'Некорректное изображение'; // Выводим ошибку, если формат изображения недопустимый
      return false;
    }
    if ($x_o + $w_o > $w_i) $w_o = $w_i - $x_o; // Если ширина выходного изображения больше исходного (с учётом x_o), то уменьшаем её
    if ($y_o + $h_o > $h_i) $h_o = $h_i - $y_o; // Если высота выходного изображения больше исходного (с учётом y_o), то уменьшаем её
    $img_o = imagecreatetruecolor($w_o, $h_o); // Создаём дескриптор для выходного изображения
    imagecopy($img_o, $img_i, 0, 0, $x_o, $y_o, $w_o, $h_o); // Переносим часть изображения из исходного в выходное
    $func = 'image'.$ext; // Получаем функция для сохранения результата
    return $func($img_o, $save); // Сохраняем изображение в тот же файл, что и исходное, возвращая результат этой операции
  }

?>