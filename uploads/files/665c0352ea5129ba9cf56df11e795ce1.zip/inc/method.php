<?php
include('function.php');
include('config.php');
require_once('../core/model.php');
include('lib/resize-class.php');

switch($_POST[m]){
    case 1:
        $text = htmlspecialchars($_POST['text']);
        $id =   validate('int',  $_POST['id']);
        
        $getAddComment = getAddComment($text, $id);
        
        if($getAddComment['status']){
            exit(json_encode(array('status' => '1',
                                   'name'   => $getAddComment['name'], 
                                   'avatar' => $getAddComment['avatar'],
                                   'text'   => $getAddComment['text'],
                                   'date'   => getDates($getAddComment['date']) )));
        }else{
            exit(json_encode(array('status' => '0', 'mgs' => $getAddComment['msg']))); 
        }
    break;
        
    case 2:  // добавление нового МК
        $title = validate('text', $_POST['title']);
        $adress  = htmlspecialchars($_POST['adress']);
        $link_adress  = urlencode($_POST['link_adress']);
        $catid  = validate('int', $_POST['catid']);
        $img  = urlencode($_POST['img']);
        $full_text  = validate('text', $_POST['full_text']);
        $full_text = urldecode($full_text);
        $date_time  = addslashes($_POST['date_time']);
        $mc_time  = addslashes($_POST['mc_time']);
        $pre_text  = urldecode($_POST['pre_text']);
        $price  = htmlspecialchars($_POST['price']);
        $email  = htmlspecialchars($_POST['email']);
         
           
        $copyFiles = copyFiles(urldecode($img), FOLDER.'/img/images/');
        
        if(!$copyFiles[status]){
            $img = DOMAIN."img/icons/default_img.jpg";
        }else{
            $img = $copyFiles[url];
            //clearTemp($_SERVER['DOCUMENT_ROOT'].'/img/temp/');
        }
        
        $params = array(
               'title' => $title,
               'adress' => $adress,
               'adress_link' => $link_adress,
               'catid' => $catid,
               'img' => $img,
               'text' => $full_text,
               'date' => $date_time,
               'mc_time' => $mc_time,
               'email' => $email,
               'price' => $price,
               'status' => htmlspecialchars($_POST['status']),
               'pre_text' => $pre_text,
               'group' => htmlspecialchars($_POST['group']),
               'group_plus' => htmlspecialchars($_POST['group_plus'])
           ); 
        
        $setAddMasterClass = mysql_insert_array('sg_master_class', $params, false);
        if($setAddMasterClass['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно добавлена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setAddMasterClass[err])));
        }
    break;
        
    case 2.1: //изменить МК
        $title = validate('text', $_POST['title']);
        $adress  = htmlspecialchars($_POST['adress']);
        $link_adress  = urlencode($_POST['link_adress']);
        $catid  = validate('int', $_POST['catid']);
        $img  = urlencode($_POST['img']);
        $full_text  = validate('text', $_POST['full_text']);
        $full_text = urldecode($full_text);
        $date_time  = addslashes($_POST['date_time']);
        $mc_time  = addslashes($_POST['mc_time']);
        $id = validate('int', $_POST['id']);
        $pre_text  = urldecode($_POST['pre_text']);
        $price  = htmlspecialchars($_POST['price']);
        $email  = htmlspecialchars($_POST['email']);
           
        $copyFiles = copyFiles(urldecode($img), FOLDER.'/img/images/');
        
        if(!$copyFiles[status]){
            $img = urldecode($img);
        }else{
            $img = $copyFiles[url];
            //clearTemp($_SERVER['DOCUMENT_ROOT'].'/img/temp/');
        }
        
        $params = array(
               'title' => $title,
               'adress' => $adress,
               'adress_link' => $link_adress,
               'catid' => $catid,
               'img' => $img,
               'email' => $email,
               'text' => $full_text,
               'date' => $date_time,
               'mc_time' => $mc_time,
               'price' => $price,
               'pre_text' => $pre_text,
               'status' => htmlspecialchars($_POST['status']),
               'group' => htmlspecialchars($_POST['group']),
               'group_plus' => htmlspecialchars($_POST['group_plus'])
           ); 
        
        $mysqlUpdateArray = mysql_update_array('sg_master_class', $params, array('id' => $id));
        
        if($mysqlUpdateArray['status']){
            exit(json_encode(array('status' => true,  'msg' => 'Изменения успешно сохранены')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqlUpdateArray[err])));
        }
        
    break;
        
    case 3: //Добавить категорию МК
        $title = validate('text', $_POST['title']);
        
        $params = array(
            'title' => $title
        );
        
        $setAddMasterClass = mysql_insert_array('sg_calid_master_class', $params, false);
        
        if($setAddMasterClass['status']){
            exit(json_encode(array('status' => true, 
                                   'msg' => 'Категория успешно добавлена!', 
                                   'id' => $setAddMasterClass['mysql_insert_id'],
                                   'title' => $title)));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setAddMasterClass[err])));
        }
    break;
        
    case 4: //удалить категорию
        $id = validate('int', $_POST['id']);
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_calid_master_class'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break; 
        
    case 5: //удалить мк
        $id = validate('int', $_POST['id']);
        
        $imgMasterClass = getMasterClassData($id); // получаем ссылку на удаляемый файл
        
        $deleteFile = deleteFile(array('file' => $imgMasterClass['img']));
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_master_class'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break;
        
    case 5.1: //удалить мк
        $id = validate('int', $_POST['id']);
        $params = array(
            'id'    => $id,
            'table' => 'sg_pages'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break;
        
    case 6: //удалить gallery
        $id = validate('int', $_POST['id']);
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_gallery'
        );
        
        $arrayImg = getGalleryData($id);
        $deleteFiles = deleteFiles($arrayImg['img']);
        $setDeleteDB = setDeleteDB($params);
        
        $paramsImg = array(
            'g_id'    => $id,
            'table' => 'sg_gallery_img'
        );
        
        $setDeleteImg = setDeleteDB($paramsImg);
       
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break;
        
    case 6.1: //Добавить галлерею
        $title = validate('text', $_POST['title']);
        $loc = validate('int', $_POST['loc']);
        $status = validate('int', $_POST['status']);
        
        $params = array(
            'title'  => $title,
            'loc'    => $loc,
            'status' => $status
        );
        
        $setAddMasterClass = mysql_insert_array('sg_gallery', $params, false);
        
        if($setAddMasterClass['status']){
            exit(json_encode(array('status' => true, 
                                   'msg' => 'Галлерея успешно создана, теперь загрузите в нее фото!', 
                                   'id' => $setAddMasterClass['mysql_insert_id']
                                   )));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setAddMasterClass[err])));
        }
    break;
        
    case 6.2: //Изменить галлерею
        $title = validate('text', $_POST['title']);
        $loc = validate('int', $_POST['loc']);
        $id = validate('int', $_POST['id']);
        $status = validate('int', $_POST['status']);
        
        $params = array(
            'title'  => $title,
            'loc'    => $loc,
            'status' => $status
        );
        
        $mysqlUpdateArray = mysql_update_array('sg_gallery', $params, array('id' => $id));
        
        if($mysqlUpdateArray['status']){
            exit(json_encode(array('status' => true,  'msg' => 'Изменения успешно сохранены')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqlUpdateArray[err])));
        }
    break;
        

        
case 7: //фото для мк
$dir_upload = '../img/';
$updir = "temp";
        if($_FILES['userfile']['error'] == 1){
		    exit(json_encode(array("success" => false, "message" => "error size file")));
		}
		
		$imageinfo = getimagesize($_FILES['file']['tmp_name']);
        if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg') {
            exit(json_encode(array("success" => false, "message" => "error type file")));
        }
		
		$uploaddir = $dir_upload.preg_replace('/[^\w]/','',$updir).'/'; 
        if(!is_dir($uploaddir)) mkdir($uploaddir, 0700); 
        $file_name = $_FILES['file']['name'];
        $fileArr = explode('.', $file_name);
		$random = uniqid("mc_");
        $file_md5 = $random.'.jpg';
		$file = $uploaddir.basename($file_md5);
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) {
         $tempImg = $_SERVER[DOCUMENT_ROOT].'/'.FOLDER.'/img/'.$updir.'/'.$file_md5;
         
        crop($tempImg, $tempImg);
        resize($tempImg, $tempImg, '200', '200');
		 $output = array("success" => true, "message" => "Success!", "file" => FOLDER.'/img/'.$updir.'/'.$file_md5);
		}else{
		 $output = array("success" => false, "error" => "Failure!");
	    }

if (($iframeId = (int)$_GET["_iframeUpload"]) > 0) { 

	header("Content-Type: text/html; charset=utf-8");

?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<script type="text/javascript">

var data = {
	id: <?php echo $iframeId; ?>,
	type: "json",
	data: <?php echo json_encode($output); ?>
};

parent.simpleUpload.iframeCallback(data);

</script>
</body>
</html>
<?php

} else { //new browser...

	header("Content-Type: application/json; charset=utf-8");
	echo json_encode($output);

}
break;
        
/*================================ Фото для отзыва=======================================================*/        
case 7.1: 
$dir_upload = '../img/';
$updir = "temp";
        if($_FILES['userfile']['error'] == 1){
		    exit(json_encode(array("success" => false, "message" => "error size file")));
		}
		
		$imageinfo = getimagesize($_FILES['file']['tmp_name']);
        if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg') {
            exit(json_encode(array("success" => false, "message" => "error type file")));
        }
		
		$uploaddir = $dir_upload.preg_replace('/[^\w]/','',$updir).'/'; 
        if(!is_dir($uploaddir)) mkdir($uploaddir, 0700); 
        $file_name = $_FILES['file']['name'];
        $fileArr = explode('.', $file_name);
		$random = uniqid("mc_");
        $file_md5 = $random.'.jpg';
		$file = $uploaddir.basename($file_md5);
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) {
         $tempImg = $_SERVER[DOCUMENT_ROOT].'/'.FOLDER.'/img/'.$updir.'/'.$file_md5;
         
        crop($tempImg, $tempImg);
        resize($tempImg, $tempImg, '200', '200');
         
		 $output = array("success" => true, "message" => "Success!", "file" => FOLDER.'/img/'.$updir.'/'.$file_md5);
		}else{
		 $output = array("success" => false, "error" => "Failure!");
	    }

if (($iframeId = (int)$_GET["_iframeUpload"]) > 0) { 

	header("Content-Type: text/html; charset=utf-8");

?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<script type="text/javascript">

var data = {
	id: <?php echo $iframeId; ?>,
	type: "json",
	data: <?php echo json_encode($output); ?>
};

parent.simpleUpload.iframeCallback(data);

</script>
</body>
</html>
<?php

} else { //new browser...

	header("Content-Type: application/json; charset=utf-8");
	echo json_encode($output);

}
    break;
        
/*================================ Превью для видео =======================================================*/        
case 7.2: 
$dir_upload = '../img/';
$updir = "temp";
        if($_FILES['userfile']['error'] == 1){
		    exit(json_encode(array("success" => false, "message" => "error size file")));
		}
		
		$imageinfo = getimagesize($_FILES['file']['tmp_name']);
        if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg') {
            exit(json_encode(array("success" => false, "message" => "error type file")));
        }
		
		$uploaddir = $dir_upload.preg_replace('/[^\w]/','',$updir).'/'; 
        if(!is_dir($uploaddir)) mkdir($uploaddir, 0700); 
        $file_name = $_FILES['file']['name'];
        $fileArr = explode('.', $file_name);
		$random = uniqid("mc_");
        $file_md5 = $random.'.jpg';
		$file = $uploaddir.basename($file_md5);
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) {
         $tempImg = $_SERVER[DOCUMENT_ROOT].'/'.FOLDER.'/img/'.$updir.'/'.$file_md5;
         $img = $_SERVER[DOCUMENT_ROOT].'/'.FOLDER.'/img/gallery/min/'.$file_md5;
         
            $resizeObj = new resize($tempImg);
            $resizeObj -> resizeImage(320, 240, 'crop'); /*Resize image (options: exact, portrait, landscape, auto, crop)*/
            $resizeObj -> saveImage($img, 100);
         
		 $output = array("success" => true, "message" => "Success!", "file" => FOLDER.'/img/gallery/min/'.$file_md5);
		}else{
		 $output = array("success" => false, "error" => "Failure!");
	    }

if (($iframeId = (int)$_GET["_iframeUpload"]) > 0) { 

	header("Content-Type: text/html; charset=utf-8");

?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<script type="text/javascript">

var data = {
	id: <?php echo $iframeId; ?>,
	type: "json",
	data: <?php echo json_encode($output); ?>
};

parent.simpleUpload.iframeCallback(data);

</script>
</body>
</html>
<?php

} else { //new browser...

	header("Content-Type: application/json; charset=utf-8");
	echo json_encode($output);

}
    break;
        
case 8: //фото для галлерии

$dir_upload = '../img/';
$updir = "gallery";
        
        if($_FILES['userfile']['error'] == 1){
		    exit(json_encode(array("success" => false, "message" => "error size file")));
		}
		
		$imageinfo = getimagesize($_FILES['file']['tmp_name']);
        if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg') {
            exit(json_encode(array("success" => false, "message" => "error type file")));
        }
		
		$uploaddir = $dir_upload.preg_replace('/[^\w]/','',$updir).'/'; 
        if(!is_dir($uploaddir)) mkdir($uploaddir, 0700); 
        $file_name = $_FILES['file']['name'];
        $fileArr = explode('.', $file_name);
		$random = uniqid("gl_");
        $file_md5 = $random.'.jpg';
		$file = $uploaddir.basename($file_md5);
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) {
            
		$img =    $_SERVER[DOCUMENT_ROOT].'/'.FOLDER.'/img/'.$updir.'/'.$file_md5;
        $imgMin = $_SERVER[DOCUMENT_ROOT].'/'.FOLDER.'/img/'.$updir.'/min/'.$file_md5;   
        
            
        $resizeObj = new resize($img);
        $resizeObj -> resizeImage(320, 240, 'crop'); /*Resize image (options: exact, portrait, landscape, auto, crop)*/
        $resizeObj -> saveImage($imgMin, 100);
            
        if($resizeObj){
             
            $params = array(
                'g_id' => validate('int', $_POST[id]),
                'img' => $file_md5,
                'img_max' => $file_md5
            );
        
            $setAddMasterClass = mysql_insert_array('sg_gallery_img', $params, false);
        
            if($setAddMasterClass['status']){
                $output = array("success" => true, "id" => $setAddMasterClass['mysql_insert_id'], "file" => DOMAIN.'img/'.$updir.'/min/'.$file_md5);
            }else{
                $output = array("success" => false, "error" => $setAddMasterClass[err]);
	       }
        }else{
                $output = array("success" => false, "error" => 'Файл '.$file_md5.' не загружен');
        }
        
        }

if (($iframeId = (int)$_GET["_iframeUpload"]) > 0) { 

	header("Content-Type: text/html; charset=utf-8");

?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<script type="text/javascript">

var data = {
	id: <?php echo $iframeId; ?>,
	type: "json",
	data: <?php echo json_encode($output); ?>
};

parent.simpleUpload.iframeCallback(data);

</script>
</body>
</html>
<?php

} else { //new browser...

	header("Content-Type: application/json; charset=utf-8");
	echo json_encode($output);

}
    break;
        
    case 9: //удалить 1 фото из gallery
        $id = validate('int', $_POST['id']);
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_gallery_img'
        );
        
        $arrayImg = getGalleryImgList($id);
        $img = array(array($arrayImg['img']));
        $deleteFiles = deleteFiles($img);
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Изображение успешно удалено!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break;
        
case 10: // сортировка фото в базе
    require_once('config.php');
    $new_pos = 1;
    foreach ($_POST['punkts'] as $item)
    {
      mysqli_query($id_db, "UPDATE `sg_gallery_img` SET `id_sort` = '{$new_pos}' WHERE `id` = '{$item}'");
      $new_pos++;
    }
        
break;
        
case 10.2: // сортировка катнгорий мк
    require_once('config.php');
    $new_pos = 1;
    foreach ($_POST['punkts'] as $item)
    {
      mysqli_query($id_db, "UPDATE `sg_calid_master_class` SET `id_sort` = '{$new_pos}' WHERE `id` = '{$item}'");
      $new_pos++;
    }
        
break;
        
        
case 10.3: // сортировка отзывов
    require_once('config.php');
    $new_pos = 1;
    foreach ($_POST['punkts'] as $item)
    {
      mysqli_query($id_db, "UPDATE `sg_recals` SET `id_sort` = '{$new_pos}' WHERE `id` = '{$item}'");
      $new_pos++;
    }
        
    echo $new_pos;
        
break;
        
case 10.4: // сортировка мастерклассов
    require_once('config.php');
    $new_pos = 1;
    foreach ($_POST['punkts'] as $item)
    {
      mysqli_query($id_db, "UPDATE `sg_master_class` SET `id_sort` = '{$new_pos}' WHERE `id` = '{$item}'");
      $new_pos++;
    }
        
    echo $new_pos;
        
break;
        
case 10.5: // сортировка gallery
    require_once('config.php');
    $new_pos = 1;
    foreach ($_POST['punkts'] as $item)
    {
      mysqli_query($id_db, "UPDATE `sg_gallery` SET `id_sort` = '{$new_pos}' WHERE `id` = '{$item}'");
      $new_pos++;
    }
        
    echo $new_pos;
        
break;
        
case 10.6: // сортировка gallery
    require_once('config.php');
    $new_pos = 1;
    foreach ($_POST['punkts'] as $item)
    {
      mysqli_query($id_db, "UPDATE `sg_pages` SET `id_sort` = '{$new_pos}' WHERE `id` = '{$item}'");
      $new_pos++;
    }
        
    echo $new_pos;
        
break;
    
case 11: // новый отзыв
   $copyFiles = copyFiles(urldecode($_POST[img]), FOLDER.'/img/avatar/');
        
        if(!$copyFiles[status]){
            $img = DOMAIN."img/icons/default_img2.jpg";
        }else{
            $img = $copyFiles[url];
            //clearTemp($_SERVER['DOCUMENT_ROOT'].'/img/temp/');
        }    
        
   $params = array(
       'title' => validate('text', $_POST['title']),
       'text' =>  htmlspecialchars($_POST['text']),
       'link' =>  urlencode($_POST['link']),
       'loc' =>  validate('int', $_POST['loc']),
       'img' =>  $img
   );
        
   $mysqli_insert = mysql_insert_array('sg_recals', $params, false);
   
        if($mysqli_insert['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно добавлена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqli_insert[err])));
        }        
break;
        
case 12: // изменить отзыв
   $id = validate('int', $_POST['id']);
   $copyFiles = copyFiles(urldecode($_POST['img']), FOLDER.'/img/avatar/');
        
        if(!$copyFiles[status]){
            $img = $_POST['img'];
        }else{
            $img = $copyFiles['url'];
            //clearTemp($_SERVER['DOCUMENT_ROOT'].'/img/temp/');
        }    
        
   $params = array(
       'title' => validate('text', $_POST['title']),
       'text' =>  htmlspecialchars($_POST['text']),
       'link' =>  urlencode($_POST['link']),
       'loc' =>  validate('int', $_POST['loc']),
       'img' =>  $img
   );
        
   $mysqli_update = mysql_update_array('sg_recals', $params, array('id' => $id));
   
        if($mysqli_update['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Изменения успешно сохранены!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqli_update[err])));
        }        
break;
        
case 13: //удалить отзыв
        $id = validate('int', $_POST['id']);
        
        $imgRecal = getRecalData($id); // получаем ссылку на удаляемый файл
        
        $deleteFile = deleteFile(array('file' => $imgRecal['img']));
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_recals'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break; 
        
    case 14: //удалить комментарий
        $id = validate('int', $_POST['id']);
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_comments'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
    break;
        
    case 15: //Добавить пользователя в чс
        $id = validate('int', $_POST['id']);
        
        if(blackListUser($id)){
            $ban = '0';
        }else{
            $ban = '1';
        }
        
        //$ban = '0';
        
        $params = array(
            'blackList' => $ban
        );
        
        $mysqli_update = mysql_update_array('sg_users', $params, array('uid' => $id));
        
        if($mysqli_update['status']){
            if($ban){
                exit(json_encode(array('status' => true, 'msg' => 'Пользователь добавлен в ЧС', 'ban' => true)));
            }else{
                exit(json_encode(array('status' => true, 'msg' => 'Пользователь удален из ЧС', 'ban' => false)));
            }
            
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqli_update[err])));
        }
        
break;
        
case 16: //удалить пользователя
        $id = validate('int', $_POST['id']);
        
        $params = array(
            'id'    => $id,
            'table' => 'sg_users'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Пользователь успешно удален!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
        
break;
        
case 17: // изменить страницу
   $id = validate('int', $_POST['id']);
   
   $copyFiles = copyFiles(urldecode($_POST['img']), FOLDER.'/img/images/');
        
        if(!$copyFiles[status]){
            $img = $_POST['img'];
             
        }else{
            $img = $copyFiles['url'];
            //clearTemp($_SERVER['DOCUMENT_ROOT'].'/img/temp/');
        }    
        
   $params = array(
       'title' => validate('text', $_POST['title']),
       'keywords' => validate('text', $_POST['keywords']),
       'cat' => validate('int', $_POST['cat']),
       'password' => $_POST['password'],
       'text' =>  htmlspecialchars(urldecode($_POST['text'])),
       'img'  =>  $img
   );
        
   $mysqli_update = mysql_update_array('sg_pages', $params, array('id' => $id));
   
        if($mysqli_update['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Изменения успешно сохранены!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqli_update[err])));
        }        
break;
 
        
/*добавить страницу*/
case 18:
      $copyFiles = copyFiles(urldecode($_POST['img']), FOLDER.'/img/images/');
        
        if(!$copyFiles[status]){
            $img = '';
        }else{
            $img = $copyFiles['url'];
            //clearTemp($_SERVER['DOCUMENT_ROOT'].'/img/temp/');
        }    
        
   $params = array(
       'title' => validate('text', $_POST['title']),
       'keywords' => validate('text', $_POST['keywords']),
       'cat' => validate('int', $_POST['cat']),
       'password' => $_POST['password'],
       'text' =>  htmlspecialchars(urldecode($_POST['text'])),
       'img'  =>  $img
   );  
        
        $mysqli_insert = mysql_insert_array('sg_pages', $params, false);
   
        if($mysqli_insert['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Страница успешно добавлена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqli_insert[err])));
        }
break;
        
/*Проверка пароля*/
case 19:
    if(empty($_POST['pass'])){
        exit(json_encode(array('status' => false, 'err' => 'Поле не должно быть пустым')));
    }
        
    $page = getPagesData($_POST['id']);
        if($page['password'] != $_POST['pass']){
            exit(json_encode(array('status' => false, 'err' => 'Не верный пароль. Вход осуществляется только по паролю указанному в договоре на проведение свадебной фотосессии')));
        }else{
            setcookie('page_'.$page['id'], md5($page['password']), time()+(60*60*24*30), '/');
            exit(json_encode(array('status' => true)));
        }
break;
        
case 204: //удалить заказ
    $id = validate('int', $_POST['id']);
    $params = array(
        'id_order'    => $id,
        'table' => 'sg_orders'
    );
        
        $setDeleteDB = setDeleteDB($params);
    if($setDeleteDB['status']){
                exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
            }else{
                exit(json_encode(array('status' => false, 'err' => $setDeleteDB[err])));
            }
break;
        
case 206:
        $col = array(
            'name' => 'tour_params',
            'profile' => 'user_select_wedding',
            'price' => 'tour_type_food',
            'status' => 'status',
        );
        
        $params = array(
            $col[$_POST['col']] => $_POST['param']
        );
        
        $mysqlUpdateArray = mysql_update_array('sg_orders', $params, array('id_order' => $_POST['id']));
        
        if($mysqlUpdateArray['status']){
            exit(json_encode(array('status' => true,  'msg' => 'Изменения успешно сохранены')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $mysqlUpdateArray[err])));
        }
break;
        
case 207:
 $id = validate('int', $_POST['id']);
$params = array(
            'id_order'    => $id,
            'table' => 'sg_orders'
        );
        
        $setDeleteDB = setDeleteDB($params);
        
        if($setDeleteDB['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Запись успешно удалена!')));
        }else{
            exit(json_encode(array('status' => false, 'msg' => $setDeleteDB[err])));
        }
break;
        
case 210:
        $params = array(
            'id_order' => $_POST['id'],
            'user_data' => $_POST['name'],
            'user_phone' => $_POST['phone'],
            'user_select_wedding' => $_POST['profile'],
            'tour_start_date' => $_POST['date']
        );
        
        if( empty($params['user_data']) or empty($params['user_phone']) or empty($params['user_select_wedding']) or empty($params['tour_start_date'])){
            exit(json_encode(array('status' => false, 'err' => 'Все поля должны быть заполнены')));
        }
        
        $dataSpecialist = getMasterClassData($params['id_order']);
        $specialistEmail = $dataSpecialist['email'];
        
        require_once($_SERVER['DOCUMENT_ROOT'].'/skins/s_template.php');
        
        $specialist = send_notification($specialistEmail, $message);
        $administrator = send_notification(EMAIL_ADDRESS, $message);
        
        if(!$specialist or !$administrator){
            exit(json_encode(array('status' => false, 'err' => 'Ошибка отправки, попробуйте пожалуйста позже')));
        }
        
        $params['tour_country'] = '<a href="http://sg-wedding.ru/specialist/'.$dataSpecialist['masterId'].'.html">'.$dataSpecialist['masterTitle'].'</a>';
        $params['tour_params'] = $dataSpecialist['masterTitle'];
        $params['tour_cat_hotel'] = $dataSpecialist['catidTitle'];
        unset($params['id_order']);
        $mysqli_insert = mysql_insert_array('sg_orders', $params, false);
   
        if($mysqli_insert['status']){
            exit(json_encode(array('status' => true, 'msg' => 'Cпасибо за ваш заказ! <br /> В случае если в течении 24-х часов, специалист с вами не связался, значит данная дата у него уже занята. Поэтому можете оставить завки на разных специалистов на всякий случай =) <span id="okay">Хорошо</span>')));
        }else{
            exit(json_encode(array('status' => false, 'err' => $mysqli_insert[err])));
        }
        
        
        
    break;
    
case 211: //добавить видео
      $params = array(
                'g_id' => $_POST['id'],
                'img' => basename($_POST['img']),
                'img_max' => $_POST['lnk'],
                'type' => 1,
            );
        
            $setAddMasterClass = mysql_insert_array('sg_gallery_img', $params, false);
        
            if($setAddMasterClass['status']){
                 exit(json_encode(array("status" => true, "id" => $setAddMasterClass['mysql_insert_id'], "file" => DOMAIN.'img/gallery/min/'.$params['img'])));
            }else{
                 exit(json_encode(array("status" => false, "err" => $setAddMasterClass[err])));
	       }  
break;
        
    case 'modal' :
        switch($_POST['type']){
            case 'modal_attach_video':
                 include('../admin/view/cp_attach_video.php');
                 exit(json_encode(array("status" => true, 'html' => $html)));
            break;
        }
    break;
        
    default: exit(json_encode(array('status' => false, 'err' => 'error not mid')));    
}//swith

?>