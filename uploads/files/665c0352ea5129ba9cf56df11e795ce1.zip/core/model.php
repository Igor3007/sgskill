<?php session_start();

/*=== Получение коментариев к уроку ===*/

function getComments($id_lesson){
   global $id_db;
   $query = mysqli_query($id_db, "SELECT `id`, `id_lesson`, `user`, `avatar`, `text_comment`, `date_comment`, `auth_id`, `uid` 
                                     FROM `sg_comments` 
                                     WHERE `id_lesson` = '$id_lesson'
                                     ORDER BY `date_comment` DESC") or die('error_getComments:'.mysqli_error());
    
    return $query;
}

/*=== Получение коментариев к уроку ===*/



/*=== Проверка существования пользователя в базе ===*/

function getIssetUser($uid){
    global $id_db;
    $sql = "SELECT * FROM `sg_users` WHERE `uid` = '$uid'";
    $query = mysqli_query($id_db, $sql) or die('error_getIssetUser:'.mysqli_error());
    $data = mysqli_fetch_assoc($query);
    if($data){ 
        return true; 
    }else{ 
        return false; 
    }
}

/*=== Добавляем пользователя в базу ===*/
function setAddUser($userData){
    
    $_SESSION['user'] = array();
    
    global $id_db;
    require('function.php');
    
    $imgName = '/img/avatar/user_'.$userData['uid'].'.jpg';
    $patchImg = $_SERVER['DOCUMENT_ROOT'].$imgName;
    
    $data = file_get_contents($userData['avatar']);
    $file = fopen($patchImg, 'w+');
    if(fputs($file, $data)){
        $crop = crop($patchImg, $patchImg);
        $crop = resize($patchImg, $patchImg, '100', '100');
        fclose($file);
    }
    
    $userData[avatar] = DOMAIN.'/img/avatar/user_'.$userData['uid'].'.jpg';
    
    
    if(!$crop){
         $default_img = $_SERVER['DOCUMENT_ROOT'].'/img/icons/default_img2.jpg';
         $crop = resize($default_img, $patchImg, '100', '100');
    }
    
    $userData[avatar] = DOMAIN.'img/avatar/user_'.$userData['uid'].'.jpg';
    
    $params = array(
        'uid' => $userData['uid'],
        'first_name' => $userData['first_name'],
        'last_name' => $userData['last_name'],
        'link_profile' => $userData['link'],
        'avatar' => $userData['avatar'],
        'auth_id' => $userData['auth_id'],
        'date_update' => date("Y-m-d H:i:s"),
        'date' => date("Y-m-d H:i:s")
    );
    
    $query = mysql_insert_array('sg_users', $params, false);
    
    if($query['status']){
        $_SESSION['user'] = array(
            'uid'    => $userData[uid],
            'name'   => ''.$userData[first_name].' '.$userData[last_name].'',
            'avatar' => $userData[avatar],
            'auth_id' => $userData[auth_id]
        );
        
        return array(status => 1);
    }else{
        return array(status => 0, msg => 'error setAddUser: error request');
    }
}

/*=== Обновление данных о пользователе ===*/
function setUpdateUser($userData){
    global $id_db;
    require('function.php');
    
    $imgName = '/img/avatar/user_'.$userData['uid'].'.jpg';
    $patchImg = $_SERVER['DOCUMENT_ROOT'].$imgName;
    
    $data = file_get_contents($userData['avatar']);
    $file = fopen($patchImg, 'w+');
    if(fputs($file, $data)){
        $crop = crop($patchImg, $patchImg);
        $crop = resize($patchImg, $patchImg, '100', '100');
        fclose($file);
    }
    
    if(!$crop){
        $default_img = $_SERVER['DOCUMENT_ROOT'].'/img/icons/default_img2.jpg';
        $crop = resize($default_img, $patchImg, '100', '100');
     }
    
    $userData[avatar] = DOMAIN.'img/avatar/user_'.$userData['uid'].'.jpg';
    
    $params = array(
        'uid' => $userData['uid'],
        'first_name' => $userData['first_name'],
        'last_name' => $userData['last_name'],
        'link_profile' => $userData['link'],
        'avatar' => $userData['avatar'],
        'date_update' => date("Y-m-d H:i:s")
    );
    
    $query = mysql_update_array('sg_users', $params, array('uid' => $userData[uid]));
    
    if($query['status']){
        $_SESSION[user] = array(
            'uid'    => $userData[uid],
            'name'   => ''.$userData[first_name].' '.$userData[last_name].'',
            'avatar' => $userData[avatar],
            'auth_id' => $userData[auth_id]
        );
        return true;
    }else{
        return false;
    }
}

/*=== Добавить новый комментарий ===*/

function getAddComment($text, $id){
    if(blackListUser($_SESSION[user][uid])){
        return array('status' => 0, 'msg' => 'error getAddComment: user in blacklist');
    }
    
    global $id_db;
    
    $user = $_SESSION['user'];
    $user[name] = validate('text', $user[name]);
    
    $params = array(
        'id_lesson' => $id,
        'user' => $user[name],
        'avatar' => $user[avatar],
        'text_comment' => $text,
        'auth_id' => $user[auth_id],
        'uid' => $user[uid]
    );
    
    $query = mysql_insert_array('sg_comments', $params, false);
    
    if($query){
        return array('status' => 1,
                     'name'   => $user[name], 
                     'avatar' => $user[avatar],
                     'text'   => $text,
                     'date'   => date("Y-m-d H:i:s") );
    }else{
        return array('status' => 0, 'msg' => 'error getAddComment: no add comment');
    }
}

/*=== Добавить запись в базу ===*/
function mysql_insert_array($table, $data, $exclude = array()) {
     global $id_db;
    
    $fields = $values = array();

    if( !is_array($exclude) ) $exclude = array($exclude);

    foreach( array_keys($data) as $key ) {
        if( !in_array($key, $exclude) ) {
            $fields[] = "`$key`";
            $values[] = "'" . mysqli_real_escape_string($id_db, $data[$key]) . "'";
        }
    }

    $fields = implode(",", $fields);
    $values = implode(",", $values);

    if( mysqli_query($id_db, "INSERT INTO `$table` ($fields) VALUES ($values)") ) {
        return array( "status" => true,
                      "mysql_insert_id" => mysqli_insert_id($id_db),
                      "mysql_affected_rows" => mysqli_affected_rows($id_db),
                      "mysql_info" => mysqli_info($id_db)
                    );
    } else {
        return array( "status" => false, "err" => mysqli_error($id_db) );
    }

}

/*=== Список категорий Мастерклассов ===*/
function getCatidList(){
     global $id_db;

    $sql = "SELECT * FROM `sg_calid_master_class` ORDER BY `id_sort` ASC";
    $query = mysqli_query($id_db, $sql) or die('error: getCatidList '.mysqli_error($id_db));
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

/*=== Удалить запись из базы ===*/
function setDeleteDB($params){
    $id = array_keys($params);
    $id = $id[0];
    $value = $params[$id];
    require('../inc/config.php');

    $sql = "DELETE FROM `$params[table]` WHERE $id=$value";
    $query = mysqli_query($id_db, $sql);
    
    if($query){
        return array('status' => true );
    }else{
        return array('status' => false, 'err' => mysqli_error($id_db));
    }
    
}

/*=== Список Мастер-классов ===*/
function getMasterClassList($params){
    
    if($params['limit']) $LIMIT = "LIMIT ".$params['limit'];
    if($params['where']) $WHERE = "WHERE ".$params['where'];
    
     global $id_db;

    $sql = "SELECT sg_calid_master_class.id, sg_master_class.id AS masterID, sg_calid_master_class.title AS catidTitle, sg_master_class.title,  `date`, `date_create`, `catid`, `adress`, `status`, `pre_text`, `img`, `text`, `email` 
              FROM `sg_master_class`
              LEFT JOIN `sg_calid_master_class` ON sg_master_class.catid = sg_calid_master_class.id
              $WHERE 
              ORDER BY sg_master_class.id_sort ASC
              $LIMIT ";
    
    $query = mysqli_query($id_db, $sql);
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

/*=== Данные мастер класса ===*/
function getMasterClassData($id){
     global $id_db;

    $sql = "SELECT sg_calid_master_class.id AS catidId, sg_master_class.id AS masterId, sg_calid_master_class.title AS catidTitle, sg_master_class.title AS masterTitle,  `date`, `date_create`, `text`, `img`,  `adress`, `status`, `adress_link`, `mc_time`, `price`, `pre_text`, `group`, `group_plus`, `email` 
              FROM `sg_master_class`
              LEFT JOIN `sg_calid_master_class` ON sg_master_class.catid = sg_calid_master_class.id
              WHERE sg_master_class.id=$id";
    
    $query = mysqli_query($id_db, $sql) or die(mysqli_error($id_db));
    $data = mysqli_fetch_assoc($query);
    
    if($query){
        return $data;
    }else{
        return false;
    }
}

/*=== Список категорий Мастерклассов ===*/
function getGalleryList(){
     global $id_db;

    $sql = "SELECT * FROM `sg_gallery` ORDER BY `id_sort` ASC";
    $query = mysqli_query($id_db, $sql) or die('error: getCatidList '.mysqli_error());
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

/*=== Данные галлереи ===*/
function getGalleryData($id){
    global $id_db;

    $sql = "SELECT gallery.id, img.g_id, title, loc, status, img.id_sort, GROUP_CONCAT(DISTINCT img.img ORDER BY img.id_sort, img.id SEPARATOR '::' )AS img, GROUP_CONCAT(DISTINCT img.id ORDER BY img.id_sort, img.id SEPARATOR '::' )AS id_img
                  FROM `sg_gallery` AS gallery
                  LEFT JOIN `sg_gallery_img` img ON gallery.id = img.g_id
                  WHERE gallery.id = '$id'
                  GROUP BY gallery.id";
    
    $query = mysqli_query($id_db, $sql) or die('error: getGalleryData '.mysqli_error());
    
    $data = mysqli_fetch_assoc($query);
    $img = explode('::', $data['img']);
    $id_img = explode('::', $data['id_img']);
    
    $img = array_map(null, $img, $id_img);
    
    
    if($query){
        return array('data' => $data, 'img' => $img);
    }else{
        return false;
    }
}

/*=== Данные галлереи ===*/
function getGalleryPortfolio($id){
    global $id_db;

    $sql = "SELECT * FROM `sg_gallery_img`  WHERE g_id = '$id' ORDER BY `id_sort` ASC";
    
    $query = mysqli_query($id_db, $sql) or die('error: getGalleryData '.mysqli_error());
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

/*=== Обновление данных в базе ===*/
function mysql_update_array($table, $params, $id){
    global $id_db;
     
    $params_query = '';
    $id_key = array_keys($id);
    $id_key = $id_key[0];
    $id_value = $id[$id_key];
    
    foreach($params AS $key => $value){
        $params_query .='`'.$key.'`=\''.$value.'\','; 
    }
    
    $params_query =  substr($params_query, 0, -1);
    $sql = "UPDATE $table SET $params_query WHERE $id_key=$id_value";
    
    if(mysqli_query($id_db, $sql)){
        return array( "status" => true);
    }else{
        return array( "status" => false, 'err' => mysqli_error($id_db).$params_query);
    }
    
    
}

/*=== Список фото из галлереи ===*/
function getGalleryImgList($id){
     global $id_db;
    
    if($id) $where = 'WHERE id='.$id.'';
        
    $sql = "SELECT * FROM `sg_gallery_img` $where";
    $query = mysqli_query($id_db, $sql);
    
    if($id){
        $data = mysqli_fetch_assoc($query);
        return $data;
    }else{
        return $query;
    }
    
}

/*=== Список отзывов ===*/
function getRecalsList($loc){
     global $id_db;
    
    if($loc) $where = 'WHERE loc='.$loc.'';
        
    $sql = "SELECT * FROM `sg_recals` $where ORDER BY id_sort, id DESC";
    $query = mysqli_query($id_db, $sql);
    
    if($query){
        return $query;
    }else{
        return $query;
    }
    
}

/*=== Данные отзыва ===*/
function getRecalData($id){
    global $id_db;

    $sql = "SELECT * FROM `sg_recals` WHERE id=$id";
    $query = mysqli_query($id_db, $sql) or die('error: getCatidList '.mysqli_error());
    
    $data = mysqli_fetch_assoc($query);
    
    if($query){
        return $data;
    }else{
        return false;
    }
}

/*=== Последние комментарии ===*/
function getChieldCommentList(){
     global $id_db;
    
    $sql = "SELECT sg_master_class.id AS masterID, sg_comments.id AS commID, sg_master_class.title AS masterTitle, sg_comments.id_lesson AS lessonID, user, avatar,  date_comment, text_comment, auth_id, uid
      FROM `sg_comments` 
      LEFT JOIN `sg_master_class` ON sg_master_class.id = sg_comments.id_lesson
      WHERE date_comment >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
      ORDER BY date_comment DESC";
    
    $query = mysqli_query($id_db, $sql) or die('error: getChieldCommentList '.mysqli_error());
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

/*=== Все пользователи ===*/
function getUserList($params){
     global $id_db;
    
    if($params['limit_start'] && $params['limit_end']) $LIMIT = 'LIMIT '.$params['limit_start'].', '.$params['limit_end'];
    if($params['where'])       $WHERE = 'WHERE '.$params['where'];
    
    $sql = "SELECT * FROM `sg_users` $WHERE ORDER BY `date_update` DESC $LIMIT";
    
    $query = mysqli_query($id_db, $sql) or die('error: getUserList '.mysqli_error($id_db));
    
    
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

/*=== Находится ли пользователь в чс ===*/
function blackListUser ($id){
     global $id_db;
    
    $sql = "SELECT blackList FROM `sg_users` WHERE uid=$id";
    $query = mysqli_query($id_db, $sql);
    $data = mysqli_fetch_assoc($query);
    
    if($data['blackList']){
        return true;
    }else{
        return false;
    }
}

/*=== Выбириаем комментарии к мк ===*/
function getMasterClassComment($limit){
     global $id_db;
    if($limit) $limit = 'LIMIT '.$limit;
    $sql = "SELECT master.id, comm.id_lesson, master.title,    
                GROUP_CONCAT(DISTINCT comm.id ORDER BY comm.date_comment SEPARATOR '::' )AS commID,     GROUP_CONCAT(DISTINCT comm.user ORDER BY comm.date_comment SEPARATOR '::' )AS commUser,
                GROUP_CONCAT(DISTINCT comm.avatar ORDER BY comm.date_comment SEPARATOR '::' )AS commAvatar,
                GROUP_CONCAT(DISTINCT comm.text_comment ORDER BY comm.date_comment SEPARATOR '::' )AS commText,
                GROUP_CONCAT(DISTINCT comm.date_comment ORDER BY comm.date_comment SEPARATOR '::' )AS commDate,
                GROUP_CONCAT(DISTINCT comm.uid ORDER BY comm.date_comment SEPARATOR '::' )AS commUserID
                  FROM `sg_master_class` AS master
                  RIGHT JOIN `sg_comments` AS comm ON master.id = comm.id_lesson
                  GROUP BY master.id
                  ORDER BY commDate DESC
                  $limit";
    $query = mysqli_query($id_db, $sql);
    
    
    return $query;
}

/*=== данные pages ===*/

function getPagesData($id, $cat=false){
    
    global $id_db;
    
    if($id) $WHERE = 'WHERE id='.$id;
    if($cat) $WHERE = 'WHERE cat='.$cat;
    
    $sql = "SELECT * FROM `sg_pages` $WHERE ORDER BY `id_sort` ASC";
    $query = mysqli_query($id_db, $sql);
    
    
    if($query){
        if($id){
            return $data = mysqli_fetch_assoc($query);
        }else{
            return $query;
        }
    }else{
        return false;
    }
}

/*===список галлерей для портфолио===*/

function getPortfolioList($loc){
    global $id_db;
    if($limit) $limit = 'LIMIT '.$limit;
    $sql = "SELECT * FROM `sg_gallery`  WHERE loc = $loc AND status = 1 ORDER BY `id_sort` ASC ";
    $query = mysqli_query($id_db, $sql) or die(mysqli_error());
    
    if($query){
        return $query;
    }else{
        return false;
    }
    
}

/*=== Список мастерклассов для фронтенда ===*/
function getMastersClassList(){

    global $id_db;

    $sql = "SELECT catid.title AS catidTitle, 
	    GROUP_CONCAT(DISTINCT master.img ORDER BY master.id SEPARATOR '::' )AS masterImg,
        GROUP_CONCAT(DISTINCT master.text ORDER BY master.id SEPARATOR '::' )AS masterText,
        GROUP_CONCAT(DISTINCT master.id ORDER BY master.id SEPARATOR '::' )AS masterID,
        GROUP_CONCAT(DISTINCT master.title ORDER BY master.id SEPARATOR '::' )AS masterTitle
                  FROM `sg_calid_master_class` AS catid
                  LEFT JOIN `sg_master_class` AS master ON catid.id = master.catid
                  WHERE master.status = 1
                  GROUP BY catid.title
                  ORDER BY catid.id_sort ASC ";
    
    
    $query = mysqli_query($id_db, $sql);
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

function getGalleryPreg($matches){
    $id_gallery = filter_var($matches[0], FILTER_SANITIZE_NUMBER_INT);
    $data = getGalleryData($id_gallery);
    if(empty($data['data']['id'])){
        return false;
    }
    $gallery = getGalleryPortfolio($id_gallery);
    while($gal = mysqli_fetch_assoc($gallery)){
        $foto .= '<div class="'.(!$gal['type'] ? 'item-foto mfp-image':'item-video mfp-iframe').'" > <a href="'.DOMAIN.'/img/gallery/'.$gal['img_max'].'"> <img src="'.DOMAIN.'/img/gallery/min/'.$gal['img'].'" alt="'.$data['data']['title'].' Слава Гребенкин" /></a> </div>';
    }
     
    $html = '<div class="item-portfolio attach">
                <div class="header-portfolio">
                    <span>'.$data['data']['title'].'</span>
                </div>
                <div class="gallery-portfolio">
                    <div class="wrap-gallery">
                         '.$foto.'
                    </div>
                </div>
            </div>';
    return $html;
}
  
function getOrders($params){
    if($params['limit']) $LIMIT = "LIMIT ".$params['limit'];
    if($params['where']) $WHERE = "WHERE ".$params['where'];
    
     global $id_db;

    $sql = "SELECT * FROM `sg_orders` $WHERE ORDER BY date DESC $LIMIT";
    $query = mysqli_query($id_db, $sql);
    
    if($query){
        return $query;
    }else{
        return false;
    }
}

?>