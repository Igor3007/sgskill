<?php 
require_once('./inc/config.php');
require_once('model.php');
require_once('./inc/function.php');

switch($_GET[v]){
    case'specialists': // Специалисты
        $catid = getCatidList(); 
        
        $view = array(
            'skin' => 's_specialists',
            'title' => 'Специалисты',
            'keywords' => 'Огромный выбор специалистов для свадьбы',
            'desc' =>  'Огромный выбор специалистов для свадьбы'
        );
       
    break;

     case'specialist': //Станица специалиста
        $id_lesson = $_GET[id];
        $data = getMasterClassData($id_lesson); 
        $view = array(
            'skin' => 's_specialist',
            'title' => $data['masterTitle'].' - sg-wedding.ru',
            'keywords' => 'Огромный выбор специалистов для свадьбы',
            'desc' =>  'Огромный выбор специалистов для свадьбы'
        );
    break;

    case'partners': // Партнеры
        $data = getPagesData(15); 
        $view = array(
            'skin' => 's_page',
            'title' => 'Партнеры',
            'keywords' => 'Наши партнеры',
            'desc' =>  'Наши партнеры'
        );
       
         
    break;
        
    case'contacts': // Партнеры
        $data = getPagesData(17); 
        $view = array(
            'skin' => 's_page',
            'title' => 'Партнеры',
            'keywords' => 'Наши партнеры',
            'desc' =>  'Наши партнеры'
        );
       
         
    break;
            
    case'page':
        $data = getPagesData($_GET['id']);
        $view = array(
            'skin' => 's_page',
            'title' => $data['title'],
            'keywords' =>  $data['keywords'],
            'desc' =>  $data['title']
        );
    
    break;
        
    case'article':
        $article = getPagesData(false, 2); 
        $view = array(
            'skin' => 's_article',
            'title' => 'Статьи',
            'keywords' =>  'Slava Grebenkin, Слава Гребенкин, Свадебный фотограф, Фотограф на свадьбу, Подводный фоотограф, Подводная фотография, Под водой, Портреты, Портретный фотограф, Фотограф в Зеленограде, Москве',
            'desc' =>  'Статьи'
        );
    break;
        
    default:
        $catid = getCatidList(); 
        $view = array(
            'skin' => 's_specialists',
            'title' => 'Специалисты',
            'keywords' =>  'Slava Grebenkin, Слава Гребенкин, Свадебный фотограф, Фотограф на свадьбу, Подводный фоотограф, Подводная фотография, Под водой, Портреты, Портретный фотограф, Фотограф в Зеленограде, Москве'
        );
        
        
       
     
}
?>