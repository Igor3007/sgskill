<?php require_once 'libs/config.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
    <head>
        <meta charset="utf-8">
        <title>Менеджер изображений</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Image Manager">
        <meta name="author" content="Darius Matulionis http://matulionis.lt">

        <link href="css/bootstrap.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script type="text/javascript"> var hash = "<?= ENCRIPTED_SESSION_ID ?>";</script>
        <script type="text/javascript" src="../../tiny_mce_popup.js"></script>
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery.filedrop.js"></script>
        <script type="text/javascript" src="js/script.js"></script>
        <script type="text/javascript" src="js/swfobject.js"></script>
        <script type="text/javascript" src="js/jquery.uploadify.v2.1.4.min.js"></script>
        <script type="text/javascript" src="js/jquery.Jcrop.min.js"></script>
        <script type="text/javascript" src="js/dialog.js"></script>
    </head>
    <body>
        <br/>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span2 well">
                    <ul class="nav nav-list">
                        <li class="nav-header">Actions</li>
                        <li><a href="#" onclick="ImgManagerDialog.showTab('tab1'); ImgManagerDialog.openDirectory(null, null)"><i class="icon-book"></i>Все папки</a></li>
                        <li><a href="#" onclick="ImgManagerDialog.showTab('tab2'); ImgManagerDialog.initImageUpload();"><i class="icon-upload"></i>Загрузить изоб.</a></li>
                        <li><a href="#" onclick="ImgManagerDialog.showTab('tab3');"><i class="icon-folder-open"></i>Добавить папку</a></li>
                        <li><a href="#" onclick="ImgManagerDialog.close();"><i class="icon-stop"></i>Закрыть</a></li>
                    </ul>
                </div>
                <div class="span8 well contentContainers" id="tab1" style="display: block;">
                    <h3>Все папки</h3>
                    <div style="max-height: 250px; overflow: scroll;">
                        <div id="directoriesContainer"><!-- Directories content goes here --></div>
                    </div>
                    <h3>Изображения</h3>
                    <div style="max-height: 400px; overflow: scroll;">
                        <div id="filesContainer"><!-- Files content goes here --></div>
                        <div class="clearfix" style="height: 70px;"></div>
                    </div>
                </div>
                <div class="span8 well contentContainers" id="tab2" style="display: none;">
                    <h3>Загрузить новое изображение</h3>
                    <br/>
                    <div id="directoriesSelect"></div>
                    <div id="dropbox"></div>
                    <div id="uploadify" style="display: none;">
                        <input id="file_upload" type="file" name="file_upload" />
                        <a href="javascript:$('#file_upload').uploadifyUpload();" class="btn btn-success pull-right">Загрузить файл</a>
                    </div>
                </div>
                <div class="span8 well contentContainers" id="tab3" style="display: none;">
                    <h3>Добавить новую папку</h3>
                    <br/>
                    <div class="alert alert-success" id="dirAddSuccess" style="display: none;">Новая папка добавлена</div>
                    <div id="directoriesSelectParent"></div>
                    <label for="newFolderName">Название папки(только латиница)</label>
                    <input type="text" name="newFolderName" id="newFolderName" value="" />
                    <div class="clearfix"></div>
                    <button class="btn btn-success" href="#" onclick="ImgManagerDialog.addNewFolder($('#directoriesSelectParent').find('#directory').val(),$('#newFolderName').val())">Добавить</button>
                </div>
            </div>
        </div>
    </body>
</html>

<div class="modal fade" id="imageInserModal" style="display: none; ">
    <div class="modal-header">
        <a class="close" data-dismiss="modal">×</a>
        <h3>Вставить в текст</h3>
    </div>
    <div class="modal-body">
        <div class="thumbnail span4 pull-left" style="min-height: 150px;">
            <input type="hidden" value="" id="imgOrigWidth" />
            <input type="hidden" value="" id="imgOrigHeight" />
            <input type="hidden" value="" id="imgWebUrl" />
            <div class="pull-left">
                <label for="imgWidth" class="control-label">Ширина </label>
                <input type="text" value="" id="imgWidth" class="input-small" tabindex="1" onblur="Helppers.checkConstrains('width');"/>
            </div>
            <div class="span1">
                <input type="text" id="constrains_1" class="constrains" constrains="1" onclick="Helppers.toogleConstrains(this);"/>
            </div>
            <div class="pull-right">
                <label for="imgHeight"  class="control-label">Высота </label>
                <input type="text" value="" id="imgHeight" class="input-small" tabindex="2" onblur="Helppers.checkConstrains('height');"/>
            </div>
            <div class="pull-left">
                <label for="imgAlt" class="control-label">Описание(для поисковика) </label>
                <input type="text" value="" id="imgAlt" tabindex="3"/>
            </div>

            <div class="pull-left">
                <label for="imgAlign" class="control-label">Позиция в тексте </label>
                <select title="Positioning of this image" id="imgAlign">
                    <option value=""></option>
                    <option value="left">Лево</option>
                    <option value="right">Право</option>
                    <option value="bottom">Низ</option>
                    <option value="middle">Центр</option>
                    <option value="top">Верх</option>
                </select>
            </div>
        </div>
        <div class="thumbnail span2 pull-right"><img id="imgThumb" src="" height="100px"  /></div>
        <div class="clearfix"></div>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn btn-success" onclick="ImgManagerDialog.insert();">Вставить изображение</a>
        <a href="#" class="btn" onclick="$('#imageInserModal').modal('hide')">Закрыть</a>
    </div>
</div>

<div class="modal fade" id="imageCropModal" style="display: none;">
    <div class="modal-header">
        <a class="close" data-dismiss="modal">×</a>
        <h3>Обрезать изображение</h3>
    </div>
    <div class="modal-body">
        <input type="hidden" id="x" name="x" />
        <input type="hidden" id="y" name="y" />
        <input type="hidden" id="w" name="w" />
        <input type="hidden" id="h" name="h" />
        <div class="thumbnail span6" id="cropImgThubContainer">
            <img id="imgCrop" src="" />
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn btn-success" onclick="ImgManagerDialog.cropAndSave()">Обрезать и сохр. копию</a>
        <a href="#" class="btn btn-success" onclick="ImgManagerDialog.cropAndSave(true)">Обрезать и заменить</a>
        <a href="#" class="btn" onclick="$('#imageCropModal').modal('hide')">Закрыть</a>
    </div>
</div>
