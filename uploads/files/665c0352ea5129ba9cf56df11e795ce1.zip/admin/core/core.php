<?php
require_once('../core/model.php');
require_once('../inc/function.php');

$page = array(
            '1' => 'Главная',
            '2' => 'О фотографе',
            '3' => 'В тексте'
        );

$cat_page = array(
    '0' => 'Cкрытые',
    '2' => 'Статьи',
    '1' => 'Системные',
);

switch($_GET[view]){
    case 1:
       $cp_view = array(
           'title' => 'Специалисты',
           'view' => 'cp_specialists',
           'act_menu' => '1'
       );
     $pg = pagination(20, 'sg_master_class', '?view=1&', false);
     $query = getMasterClassList(array('limit' => $pg['start'].', '.$pg['end']));
    break;
        
    case 2:
       $cp_view = array(
           'title' => 'Страницы',
           'view' => 'cp_pages',
           'act_menu' => '2'
       );
        
       $query = getPagesData(false);
        
    break;
        
    case 'add':
       $cp_view = array(
           'title' => 'Добавить страницу',
           'view' => 'cp_add_pages',
           'act_menu' => '2'
       );
        
        
        
    break;
        
    case 3:
       $cp_view = array(
           'title' => 'Менеджер коментариев',
           'view' => 'cp_comment',
           'act_menu' => '3'
       );
        
       $query = getChieldCommentList();    
    break;
        
    case 4:
       $cp_view = array(
           'title' => 'Менеджер отзывов',
           'view' => 'cp_recals',
           'act_menu' => '4'
       );
        
       $query = getRecalsList(false);
    break;
        
    case 5:
       $cp_view = array(
           'title' => 'Добавить специалиста',
           'view' => 'cp_add_specialists',
           'act_menu' => '1'
       );

       $catid = getCatidList();
    break;
        
    case 6:
       $cp_view = array(
           'title' => 'Категории специалистов',
           'view' => 'cp_catid_master_class',
           'act_menu' => '1'
       );
        
       $query = getCatidList();
    break;
        
    case 7: 
       $cp_view = array(
           'title' => 'Галереи изображений',
           'view' => 'cp_gallery',
           'act_menu' => '5'
       );
        
        
        
       $query = getGalleryList();
    break;
        
    case 8: 
       $cp_view = array(
           'title' => 'Добавить новую галерею',
           'view' => 'cp_gallery_add',
           'act_menu' => '5'
       );
    
    break;
        
    case 9: 
       $cp_view = array(
           'title' => 'Редактировать галерею',
           'view' => 'cp_gallery_edit',
           'act_menu' => '5'
       );
        
       $data = getGalleryData($_GET[edit]);
       $gallery = getGalleryPortfolio($_GET['edit']);
               
    break;
        
    case 10: 
       $cp_view = array(
           'title' => 'Редактировать Специалиста',
           'view' => 'cp_edit_specialist',
           'act_menu' => '1'
       );
        
       $data = getMasterClassData($_GET[edit]);
       $catid = getCatidList();
        
    break;
        
    case 11: 
       $cp_view = array(
           'title' => 'Новый отзыв',
           'view' => 'cp_recals_add',
           'act_menu' => '4'
       );
        
    break;
        
    case 12: 
       $cp_view = array(
           'title' => 'Изменить отзыв',
           'view' => 'cp_recals_edit',
           'act_menu' => '4'
       );
        
       $data = getRecalData($_GET['edit']);
        
    break;
        
    case 13:
       $cp_view = array(
           'title' => 'Менеджер коментариев',
           'view' => 'cp_comment_article',
           'act_menu' => '3'
       );
        
       $pg = pagination(5, 'sg_master_class', '?view=13&', false);
       $query = getMasterClassList(array('limit' => $pg['start'].', '.$pg['end']));
       
    break;
        
    case 14:
       $cp_view = array(
           'title' => 'Зарегистрированные пользователи',
           'view' => 'cp_comment_user',
           'act_menu' => '3'
       );
        
        $pg = pagination(10, 'sg_users', '?view=14&', false);
        $query = getUserList(array('limit_start' => $pg['start'], 'limit_end' => $pg['end'] ));
        
       
    break; 
        
    case 15:
       $cp_view = array(
           'title' => 'Пользователь',
           'view' => 'cp_comment_user',
           'act_menu' => '3'
       );
        
        $query = getUserList(array('where' => 'uid='.$_GET[user]));
        
       
    break; 
        
    case 16:
       $cp_view = array(
           'title' => 'Редактировать страницу',
           'view' => 'cp_pages_edit',
           'act_menu' => '2'
       );
        
       $data = getPagesData($_GET['edit']);
       
    break;
        
    case 'order':
       $cp_view = array(
           'title' => 'Менеджер заказов - Новые',
           'view' => 'cp_order_new',
           'act_menu' => 'order'
       );
        
       $pg = pagination(10, 'sg_orders', '?view=order&', false);
       $query = getOrders(array('limit' => $pg['start'].', '.$pg['end']));
        
    break;
        
        
    default: 
        $cp_view = array(
           'title' => 'Мастер Классы',
           'view' => 'cp_master_class',
           'act_menu' => '1'
       );
        
       $query = getMasterClassList($params);
  }


?>