$(document).ready(function(){
    var path_method = '../../inc/method.php';
    
    $('.date_master_class').datetimepicker({
        format:'Y-m-d',
        step: 15,
        timepicker: false
    });
    
    /*=== Вывод сообщений от скриптов ===*/    
function status(type_err, message){
        if(type_err){
            $('#status').removeClass().text(message).addClass('complete');
        }else{
            $('#status').removeClass().text(message).addClass('error');
        }
        //$(window).scrollTop(0);
        setTimeout(function(){$('#status').removeClass();}, 3000);
        
    };
    
    /*==== Анимируем загрузку ====*/
    
    function loading(elem, method){
        switch(method){
            case 'start':
                var text = $(elem).text()
                $(elem).attr('disabled', 'disabled').attr('title', text).html('<span class="loading"></span>');
            break;
                
            case 'stop':
                var title = $(elem).attr('title');
                $(elem).html(title).removeAttr('disabled');
            break;
                
        }
       
    }
    
/*=== Показать настройки ===*/
    
    $(document).on('click', '.setting', function(){
        $(this).parents('.parent-setting').find('.action').toggleClass('show');
    })
    
/*=== Вывод фото ===*/
    
    function simpleSucces_one(file){
        $('.foto > img').attr('src', file).attr('title', file);
    }
    
    function simpleSucces_all(file, id, type){
        $('.box-gallery-img').append('<a class="'+type+'" id="'+id+'" href = "'+file+'">\
                                          <div class="side-delete"><span class="delite" data-id="'+id+'" data-mid="9"></span> </div>\
                                          <img src="'+file+'" />\
                                       </a>');
    }
    
/*=== Загрузка файлов на сервер ===*/

$(document).on('change', '.upload_img', function(){
        var id  = $(this).data('id');
        var mid = $(this).data('mid');
 
        $(this).simpleUpload(path_method, {
            limit: '1',
            data: {'m':mid, 'id':id},
            start: function(file){
               $('.main-uloader > h5').text(file.name);
               $('.overlay_uploader ').show();
               $('.progressBar').width(0);    
            },
 
            progress: function(progress, file){
                $('.progressBar').width(progress + "%");
            },
 
            success: function(data){
                $('.overlay_uploader ').hide();
                $('.progressBar').width(0); 
                if (data.success) {
                    status(true, 'Файл успешно загружен!')
                    switch(mid){
                        case 7: simpleSucces_one(data.file); break;
                        case 7.1: simpleSucces_one(data.file); break;
                        case 8: simpleSucces_all(data.file, data.id, 'foto-item'); break;
                        case 7.2: $('#img_video').attr('src', ''+data.file+''); break;
                    }
                } else {
                    var error = data.error;
                    status(false, 'Ошибка загрузки файла');
                }
 
            },
 
            error: function(error){
               alert(error);
            }
 
        });
 
    });
    

    
 /*=== Сохранение МК  ===*/
function sendMc(mid, id, elem) {
    loading(elem, 'start');
    $.ajax({
            type: 'POST',
            url: path_method,
            data:{
                'title':$('input[name=title]').val(),
                'email':$('input[name=email]').val(),
                'group':$('input[name=group]').val(),
                'group_plus':$('input[name=group_plus]').val(),
                'date_time':$('input[name=date_time]').val(),
                'mc_time':$('input[name=date_mc_time]').val(),
                'adress':$('input[name=adress]').val(),
                'link_adress':$('input[name=link_adress]').val(),
                'price':$('input[name=price]').val(),
                'catid':$('select[name=catid]').val(),
                'status':$('select[name=status]').val(),
                'img':$('.foto > img').attr('src'),
                'full_text': encodeURIComponent(tinyMCE.get('full_text').getContent()),
                'm':mid,
                'id':id
                },
            success: function(server_response){
                var data = eval("("+server_response+")");
                loading(elem, 'stop');
                if(data.status){
                    status(true, data.msg)
                 }else{
                    status(false, data.msg)
                }
                
            }
        })
                }

$('#send_mc').bind('click', function(e){
    var elem = $(this);
    $('.em').each(function(){
        if(!$(this).val()){
            $(this).addClass('empty');
            status(false, 'Заполните пустые поля')
        }else{
            $(this).removeClass('empty');
            
        }
        
        
     })   

     if($('.empty').length == 0){
            sendMc(2, 0, elem);
            $('.right-bar input, texarea').val('');
        }
})

$('#edit_mc').bind('click', function(){
          sendMc(2.1, $(this).data('id'), $(this));
})

/*=== Добавить Категорию ===*/

   $('#add_cp_catid').bind('click', function(){
       var elem = $(this);
       if($('#catid_name').val()){
           loading(elem, 'start');
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title': $('#catid_name').val(),
                   'm': 3
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                   loading(elem, 'stop');
                   if(data.status){
                       status(true, 'Категория успешно добавлена!')
                       $('.tg').append('<tr><td class="tg-031e table-id">'+data.id+'</td><td class="tg-031e table-title">'+data.title+'</td><td class="tg-031e table-id"><span data-id="'+data.id+'" data-mid="4" class="delite"></span></td></tr>')
                       $('#catid_name').val('')
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   }) 
  
/*=== Удалить ===*/   
$(document).on('click', '.delite, .del_user, .or-delete', function(e){
   var elem = $(this);
   e.preventDefault();
   var elem = $(this);
   if (confirm("Вы действительно хотите удалить эту запись?")){  
         loading(elem, 'start');
         $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'id': $(this).data('id'),
                   'm':  $(this).data('mid'),
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                   loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                       $(elem).parents('tr, a, .parent_del').fadeOut(300);
                   }else{
                       status(false, data.msg)
                   }
               }
           })
        }
   }) 

/*=== Добавить Галлерею ===*/

   $('#add_galley').bind('click', function(){
       if($('input[name=title]').val()){
           var elem = $(this);
           loading(elem, 'start');
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title': $('input[name=title]').val(),
                   'loc':   $('select[name=page]').val(),
                   'status':   $('select[name=status]').val(),
                   'm': 6.1
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                   loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                       
                       $('.this-gallery').show();
                       $('.upload_img').attr('data-id', ''+data.id+'');
                       $('#add_galley').remove()
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   })
   
   $(document).on('click', '#delete-foto', function(){
       $('.foto-autor > img').attr('src', '/img/images/default_img2.jpg').attr('title','');
            
})
   
/*=== Редактировать Галлерею ===*/

   $('#edit_galley').bind('click', function(){
       var elem = $(this);
       loading(elem, 'start');
       if($('input[name=title]').val()){
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title':  $('input[name=title]').val(),
                   'loc':    $('select[name=page]').val(),
                   'status': $('select[name=status]').val(),
                   'id':     $('.upload_img').data('id'),
                   'm': 6.2
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                   loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   })
    
/*=== Сортировка ===*/
if($('div').is('.box-gallery-img')){
$('.box-gallery-img').sortable(
    {
         
        opacity: 0.6,
        //placeholder: 'menu_item',
        items: 'a',
        cursor: 'crosshair',
        stop: function()
        {
            var menu_punkts = $(this).sortable("toArray");
            //alert(menu_punkts);
            
            $.ajax(
            {
                url: path_method,
                type: 'POST',
                data: {punkts: menu_punkts, m: 10},
                error: function()
                {
                    $('#message').text("Ошибка!");
                },
                success: function()
                {
                    $('#message').fadeIn(400).text("Успешно сохранено!").fadeOut(1200);
                }
                
            });
            
        }
        
    });
}
    
if($('div').is('.add-catid')){
$('.table-catid').sortable(
    {
         
        opacity: 0.6,
        //placeholder: 'menu_item',
        items: '.item-cat',
        cursor: 'crosshair',
        stop: function()
        {
            var menu_punkts = $(this).sortable("toArray");
            //alert(menu_punkts);
            
            $.ajax(
            {
                url: path_method,
                type: 'POST',
                data: {punkts: menu_punkts, m: 10.2},
                error: function()
                {
                    $('#message').text("Ошибка!");
                },
                success: function()
                {
                    $('#message').fadeIn(400).text("Успешно сохранено!").fadeOut(1200);
                }
                
            });
            
        }
        
    });
}
    
if($('div').is('.recal-table')){
$('.table-catid').sortable(
    {
         
        opacity: 0.6,
        //placeholder: 'menu_item',
        items: '.item-cat',
        cursor: 'crosshair',
        stop: function()
        {
            var menu_punkts = $(this).sortable("toArray");
            $.ajax(
            {
                url: path_method,
                type: 'POST',
                data: {punkts: menu_punkts, m: 10.3},
                error: function()
                {
                    $('#message').text("Ошибка!");
                },
                success: function()
                {
                    $('#message').fadeIn(400).text("Успешно сохранено!").fadeOut(1200);
                }
                
            });
            
        }
        
    });
}
    
if($('div').is('.mc-table')){
$('.table-catid').sortable(
    {
         
        opacity: 0.6,
        //placeholder: 'menu_item',
        items: '.item-cat',
        cursor: 'crosshair',
        stop: function()
        {
            var menu_punkts = $(this).sortable("toArray");
            $.ajax(
            {
                url: path_method,
                type: 'POST',
                data: {punkts: menu_punkts, m: 10.4},
                error: function()
                {
                    $('#message').text("Ошибка!");
                },
                success: function()
                {
                    $('#message').fadeIn(400).text("Успешно сохранено!").fadeOut(1200);
                }
                
            });
            
        }
        
    });
}
 
/*===Сортировка галлерей===*/    
if($('div').is('.table-gallery')){
$('.table-gallery table > tbody').sortable(
    {
         
        opacity: 0.6,
        //placeholder: 'menu_item',
        items: '.table-tr',
        cursor: 'crosshair',
        stop: function()
        {
            var menu_punkts = $(this).sortable("toArray");
            $.ajax(
            {
                url: path_method,
                type: 'POST',
                data: {punkts: menu_punkts, m: 10.5},
                error: function()
                {
                    $('#message').text("Ошибка!");
                },
                success: function()
                {
                    $('#message').fadeIn(400).text("Успешно сохранено!").fadeOut(1200);
                }
                
            });
            
        }
        
    });
}
    
/*===Сортировка page===*/    
if($('div').is('.pages')){
$('.table-page tbody').sortable(
    {
         
        opacity: 0.6,
        //placeholder: 'menu_item',
        items: '.item-page',
        cursor: 'crosshair',
        stop: function()
        {
            var menu_punkts = $(this).sortable("toArray");
            $.ajax(
            {
                url: path_method,
                type: 'POST',
                data: {punkts: menu_punkts, m: 10.6},
                error: function()
                {
                    $('#message').text("Ошибка!");
                },
                success: function()
                {
                    $('#message').fadeIn(400).text("Успешно сохранено!").fadeOut(1200);
                }
                
            });
            
        }
        
    });
}
    
/*=== Живое Изменение шаблона отзыва ===*/
    $('.inputLive').keyup(function(){
        var elem = $(this).data('keyup');
        var text = $(this).val();
        $('.'+elem+'').text(text);
        
        if(elem == 'link'){
            $('.name').attr('href', text);
        }
        
        var el_h = $('.recal-text').height()+5;
        $('.recal-text').css('marginTop', '-'+el_h+'px');
       
    })
    
    var el_h = $('.recal-text').height()+5;
        $('.recal-text').css('marginTop', '-'+el_h+'px');
    
    
/*=== Добавление нового отзыва ===*/
$('#add_recal').bind('click', function(){
       if($('input[name=title]').val()){
           var elem = $(this);
           loading(elem, 'start');
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title': $('input[name=title]').val(),
                   'link': $('input[name=link]').val(),
                   'loc':   $('select[name=page]').val(),
                   'text':   $('textarea[name=text]').val(),
                   'img':   $('.foto > img').attr('src'),
                   'm': 11
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                   loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                       $('input, textarea').val('');
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   }) 

/*=== Изменение отзыва ===*/
$('#edit_recal').bind('click', function(){
       if($('input[name=title]').val()){
           var elem = $(this);
           loading(elem, 'start');
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title': $('input[name=title]').val(),
                   'link': $('input[name=link]').val(),
                   'loc':   $('select[name=page]').val(),
                   'text':   $('textarea[name=text]').val(),
                   'img':   $('.foto > img').attr('src'),
                   'id':   $(this).data('id'),
                   'm': 12
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                   
                   loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   }) 

/*=== Забанить пользователя в черный список ===*/

$('.ban_user').bind('click', function(){
    var id = $(this).data('id');
    var elem = $(this);
    loading(elem, 'start');
    $.ajax({
        type: 'POST',
        url: path_method,
        data:{'id':id, m:15},
        success: function(server_response){
          var data = eval("("+server_response+")");
            loading(elem, 'stop');
            if(data.status){
                status(true, data.msg);
                if(data.ban){
                   elem.parents('.item-user').find('.user-data').prepend('<p class="blist"><span class="cell-1">Черный список:</span><span class="cell-2" style="color:red;">Этот пользователь не может оставлять комментарии</span> </p>') 
                }else{
                   elem.parents('.item-user').find('.blist').remove(); 
                }
                
            }else{
                status(false, data.err);
            }
        }
    })
})

/*=== Добавить страницу ===*/

   $('#add_page').bind('click', function(){
       if($('input[name=title]').val()){
           var elem = $(this);
           loading(elem, 'start');
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title': $('input[name=title]').val(),
                   'keywords': $('textarea[name=keywords]').val(),
                   'password': $('input[name=password]').val(),
                   'cat': $('select[name=cat]').val(),
                   'img':   $('.foto > img').attr('src'),
                   'text': encodeURIComponent(tinyMCE.activeEditor.getContent()),
                   'm': 18
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                    loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   })

/*=== Изменить страницу ===*/

   $('#edit_page').bind('click', function(){
       if($('input[name=title]').val()){
           var elem = $(this);
           loading(elem, 'start');
           $.ajax({
               type: 'POST',
               url: path_method,
               data: {
                   'title': $('input[name=title]').val(),
                   'keywords': $('textarea[name=keywords]').val(),
                   'password': $('input[name=password]').val(),
                   'cat': $('select[name=cat]').val(),
                   'img':   $('.foto > img').attr('title'),
                   'text': encodeURIComponent(tinyMCE.activeEditor.getContent()),
                   'id': $(this).data('id'),
                   'm': 17
               },
               success: function(server_response){
                   var data = eval("("+server_response+")");
                    loading(elem, 'stop');
                   if(data.status){
                       status(true, data.msg)
                   }else{
                       status(false, data.msg)
                   }
               }
           })
       }else{
           alert('Поле не должно быть пустым');
       }
   }) 
   
/*Изменить параметр*/
    $(document).on('blur', '.edit-param', function(){
        
        if($(this).attr('title') != $(this).text() )
        {
            var param = $(this).text();
            var id = $(this).parents('tr').attr('id');
            var col = $(this).data('col');
            var params = 'param='+param+'&id='+id+'&col='+col+'&m=206';
            var elem = $(this);
            loading(elem, 'start');
            $.ajax({
                    type: 'POST',
                    url: '../inc/method.php',
                    data: params,
                    dataType: 'json',
                    success: function(data){
                        if(data.status){
                            if(data.msg){
                                loading(elem, 'stop');
                            }
                         }else{
                            $('.err').text(data.err);
                            loading(elem, 'stop');
                        }
                    },
                    error: function(textStatus){
                        alert('error')
                    }
        })
        }
                    
    })   
    
    
    $('.status').change(function(){
        var status = $(this).val();
        var id = $(this).parents('tr').attr('id');
        var col = $(this).data('col');
        var elem = $(this);
        var params = 'param='+status+'&id='+id+'&col='+col+'&m=206';
        $.ajax({
                    type: 'POST',
                    url: '../inc/method.php',
                    data: params,
                    dataType: 'json',
                    success: function(data){
                        if(data.status){
                            if(data.msg){
                                 
                            }
                         }else{
                            $('.err').text(data.err);
                             
                        }
                    },
                    error: function(textStatus){
                        alert('error')
                    }
        })
    })

   

        
    /*Закрыть модальное окно*/
    $(document).on('click', '.close-modal', function(){
        $(this).parents('.modal-window').removeClass('open');
         $('html').removeClass('hidden');
    })
    function close_modal(id_modal){
        $('#'+id_modal).removeClass('open');
        $('html').removeClass('hidden');
        $('.modal-wrap-content').html('<center>Загрузка...</center>');
    }
    
/*Открыть окно*/
    $(document).on('click', '.modal-open', function(){
        var id_modal = $(this).data('modal');
        $('#'+id_modal+'').addClass('open');
         
    })
    
    function open_modal(id_modal, header_modal){
        $('#'+id_modal).addClass('open');
        $('html').addClass('hidden');
        if(header_modal){
            $('#'+id_modal).find('.modal-header > span').text(header_modal);
            $('#modal-progress').addClass('progress');
        }
        $('#'+id_modal).find('.mdl-progress').show();
    }
    
    
$(document).on('click', '#modal-attach-video', function(){
         open_modal('modal', 'Добавить видео');
         var params = 'm=' + 'modal' + '&type=' + 'modal_attach_video';
         $.ajax({
                    type: 'POST',
                    url: '../inc/method.php',
                    data: params,
                    dataType: 'json',
                    success: function(data){
                        if(data.status){
                            $('.modal-wrap-content').html(data.html);
                            $('#modal-progress').removeClass('progress');
                         }else{ $('.err').text(data.err); }
                    },
                    error: function(textStatus){
                        alert('error')
                    }
         })
    })
        
 

$(document).on('click', '#add-video', function(){
    var img = $('#img_video').attr('src');
    var lnk = $('.link-video input').val();
    var id = $('.header-load-gallery').find('.upload_img').data('id');
    
    $.ajax({
        type: 'POST',
        url: '../inc/method.php',
        data: {img:img, lnk:lnk, id:id, m:211},
        dataType: 'json',
        success: function(data){
            if(data.status){
                 simpleSucces_all(data.file, data.id, 'video-item')
                 close_modal('modal');
             }else{ status(false, data.err) }
        },
        error: function(textStatus){
            alert('error')
        }
         })
})

 
   
  
}) //ready


tinyMCE.init({
 
  mode : "exact",
  elements: "full_text, pre_text",	
  // ===========================================
  // Set THEME to ADVANCED
  // ===========================================
	
  theme : "advanced",
	
  // ===========================================
  // INCLUDE the PLUGIN
  // ===========================================
 
  plugins : "imgmanager,autolink,lists,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",
	
  // ===========================================
  // Set LANGUAGE to EN (Otherwise, you have to use plugin's translation file)
  // ===========================================
 
  language : "ru",
	 
  theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
  theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
  theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen,|,imgmanager",
 
  // ===========================================
  // Put PLUGIN'S BUTTON on the toolbar
  // ===========================================
 
  theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
	
  theme_advanced_toolbar_location : "top",
  theme_advanced_toolbar_align : "left",
  theme_advanced_statusbar_location : "bottom",
  theme_advanced_resizing : true,
	
  // ===========================================
  // Set RELATIVE_URLS to FALSE (This is required for images to display properly)
  // ===========================================
 
  relative_urls : false,
  content_css : '/css/tiny_mce.css',
  encoding: false
  
	
});