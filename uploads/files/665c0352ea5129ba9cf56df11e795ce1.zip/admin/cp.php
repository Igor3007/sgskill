<?php session_start();

define('ACCESS', '');

require_once('../inc/config.php');
    $key_access = $_GET['key_access'];
    $set_key_access = ACCESS_KEY;
    $redirect_url = 'Location: /';

if(!empty($key_access) and $key_access == $set_key_access){
       
            if(!$_SESSION[cp_id]){
            require_once('./view/login.php');
        }
         
    }else{
        if(!$_SESSION[cp_id]){
            header($redirect_url); exit();
        }
    }

     if($_SESSION[cp_id]){
            require_once('core/core.php');
            require_once('./view/cpanel.php');
        }else{
            //exit('error: not access adm');
     }
?>