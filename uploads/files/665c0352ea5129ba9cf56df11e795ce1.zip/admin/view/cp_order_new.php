<div class="wrap-order">
    
    <div class="box-orders">
        <div class="table-catid order-table">
        <table class="tg table-catid" style="width: 90%;">
          <tr>
            <th class="tg-031e">Специалист</th>
            <th class="tg-031e">Имя специалиста</th>
            <th class="tg-031e">Дата поступления</th>
            <th class="tg-031e">Дата исполнения</th>
            <th class="tg-031e">Профиль</th>
            <th class="tg-031e">Телефон</th>
            <th class="tg-031e">Стоимость</th>
            <th class="tg-031e">Статус договора</th>
            <th class="tg-031e">Удалить</th>
          </tr>
           <? while($data = mysqli_fetch_assoc($query)): ?>
                <tr id="<?=$data['id_order']?>" class="item-cat">
                  <td class="tg-031e" ><?=$data['tour_cat_hotel']?></td>
                  <td contenteditable="true" data-col="name" class="tg-031e edit-param" title="<?=$data['tour_params']?>"><?=$data['tour_params']?></td>
                  <td class="tg-031e "><?=$data['date']?></td> 
                  <td class="tg-031e  "><?=setChangeDate($data['date'], $data['tour_start_date'])?></td>
                  <td contenteditable="true" data-col="profile" class="tg-031e edit-param" title="<?=$data['user_select_wedding']?>"> <?=$data['user_select_wedding']?> </td>
                  <td class="tg-031e" > <?=$data['user_phone']?> </td>
                  <td contenteditable="true" data-col="price" class="tg-031e edit-param" title="<?=$data['tour_type_food']?>"> <?=$data['tour_type_food']?> </td>
                  <td class="tg-031e "><select name="status" class="status" data-col="status"><?=selectActive(array('Передан', 'Заключен'), $data['status'])?></select></td>
                  <td class="tg-031e table-id"><span class="delite del-catid-mc" data-id="<?=$data['id_order']?>" data-mid ="207"></span></td>
               </tr>
           <? endwhile ?> 
        </table>
        <?=$pg['button']?>
        </div>
    </div>
</div>
