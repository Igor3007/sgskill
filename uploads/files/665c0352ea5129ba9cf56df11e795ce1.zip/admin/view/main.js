$(document).ready(function() {
    
    function loading(elem, method){
        switch(method){
            case 'start':
                var text = $(elem).text()
                $(elem).attr('disabled', 'disabled').attr('title', text).html('<span class="loading"></span>');
            break;
                
            case 'stop':
                var title = $(elem).attr('title');
                $(elem).html(title).removeAttr('disabled');
            break;
                
        }
       
    }

 
$('.wrap-gallery').each(function() { // the containers for all your galleries
    $(this).find('.item-foto a').magnificPopup({
        
        type: 'image',
        gallery: {
          enabled:true,
          preload: [0,3],
          tCounter: ''
          
        }
    });
  });

    $('.item-video').magnificPopup({
        delegate: 'a', // the selector for gallery item
        type: 'iframe',
         
    });
    
$('#form-contacts input').bind('focus', function(){
     $(this).prev('.ic_24').toggleClass('active');
})

$('#form-contacts input').bind('blur', function(){
     $(this).prev('.ic_24').toggleClass('active');
})

$('#calendar').datetimepicker({
  timepicker: false,
  format:  'd-m-Y'
});

 
$('#send-contacts').bind('click', function(){
    var id = $(this).data('id');
    var params = $('#form-contacts').serialize()+ '&m=' + 210 + '&id=' + id;
    var elem = $(this);
    loading(elem, 'start');
    $.ajax({
            type: 'POST',
            url: '../inc/method.php',
            data: params,
            dataType: 'json',
            success: function(data){
                if(data.status){
                    if(data.msg){
                        loading(elem, 'stop');
                        $('.contacts-specialist').addClass('send').html('<span class="success send">'+data.msg+'</span>');
                    }
                 }else{
                    $('.err').text(data.err);
                    loading(elem, 'stop');
                }
            },
            error: function(textStatus){
                $('.err').text('Ошибка отправки =( Пожалуйста попробуйте позже');
            }
})
})

$(document).on('click', '#okay', function(){
    $('.contacts-specialist, .success').removeClass('send');
    $('#okay').remove();
})

 /*Изменить параметр*/
    $(document).on('blur', '.edit-param', function(){
        
        if($(this).attr('title') != $(this).text() )
        {
            var param = $(this).text();
            var id = $(this).parents('tr').attr('id');
            var col = $(this).data('col');
            var params = 'param='+param+'&id='+id+'&col='+col+'&m=206';
            var elem = $(this);
            loading(elem, 'start');
            $.ajax({
                    type: 'POST',
                    url: '../inc/method.php',
                    data: params,
                    dataType: 'json',
                    success: function(data){
                        if(data.status){
                            if(data.msg){
                                loading(elem, 'stop');
                            }
                         }else{
                            $('.err').text(data.err);
                            loading(elem, 'stop');
                        }
                    },
                    error: function(textStatus){
                        alert('error')
                    }
        })
        }
                    
    })   
    
});//ready

