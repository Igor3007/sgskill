<div class="about">
    <div class="foto-autor foto">
        <img alt="" src="<?=$data['img']?>">
        <input type="file" name="file" id="upload_img" data-mid="7" />
    </div>
    <div class="descr">
        <?=$data['text']?>
    </div>
</div>