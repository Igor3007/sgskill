<div class="info-gallery">
    <p>
        <label>Название галереи</label>
        <input type="text" name="title" placeholder="Например: ПРЕССА" value="<?=$data['data']['title']?>" />
    </p>
    
    <p>
        <label>Показывать на страние:</label>
        <select name="page">
            <?=selectActive($page, $data['data']['loc'])?>
        </select>
    </p>
    
    <p>
        <label>Статус:</label>
        <select name="status">
             <?=selectActive($status, $data['data']['status'])?>
        </select>
    </p>
    
    <p>
        <button id="edit_galley" class="btn-grey">Изменить</button>
    </p>
    
</div>



<div class="this-gallery" >
    <div class="header-load-gallery">
        <label class="label-line">Выберите изображения для загрузки: </label> <input class="upload_img" type="file" multiple value="Выбрать" name="file" data-id="<?=$data['data']['id']?>" data-mid="8"/>
        <button id="modal-attach-video">Добавить видео</button>
    </div>
    <div class="box-gallery-img">
           
        <? while($gal = mysqli_fetch_assoc($gallery)): ?>
         
            <a class="<?=($gal['type'] == 1 ? 'item-video':'item-foto')?>" id="<?=$gal['id']?>" href = "<?=($gal['type'] ? ''.$gal['img_max'].'':'#')?>">
                <div class="side-delete"><span class="delite" data-id="<?=$gal['id']?>" data-mid="9"></span> </div>
                <img src="<?=DOMAIN?>img/gallery/min/<?=$gal['img']?>" />
            </a>
         
        <? endwhile; ?>
        
    </div>
</div>

 

<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 