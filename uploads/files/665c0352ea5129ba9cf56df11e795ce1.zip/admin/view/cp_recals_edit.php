<div class="add-recal">
    <div class="preview">
        <div class="p_left">
            <div class="item-recal">
               <div class="recal-text animated">
                    <div class="this text" ><?=$data['text']?></div>
                    <span class="stick"></span>
               </div>
               <div class="user-avatar foto">
                  <img src="<?=($data['img'] ? $data['img'] : ''.DOMAIN.'img/icons/default_img2.jpg')?>" alt="" />
               </div>
               <h5><a target="_blank" href="http://vk.com" class="name"><?=$data['title']?></a></h5>
            </div>
            
        <p>
            <input type="file" name="file" id="upload_img" data-mid="7.1" />
        </p>
        </div>
        
  <div class="p_right">
            
    <p>
        <label>Имя Фамилия</label>
        <input type="text" value="<?=$data['title']?>" name="title" placeholder="Иван Иванов" data-keyup="name" class="inputLive" />
    </p>
        
    <p>
        <label>Ссылка</label>
        <input type="text" value="<?=urldecode($data['link'])?>" name="link" placeholder="Ссылка на профиль" data-keyup="link" class="inputLive" />
    </p>
    
    <p>
        <label>Показывать на страние:</label>
        <select name="page">
           <?=selectActive($page, $data['loc'])?>
        </select>
    </p>
            
    <p>
        <label>Oтзыв:</label>
        <textarea id="text" name="text" class="inputLive" placeholder="Текст отзыва" data-keyup="text"><?=$data['text']?></textarea>
    </p>
            
    <p>
        <button class="btn-grey" data-id="<?=$data['id']?>" id="edit_recal">Сохранить изменения</button>
    </p>
            
        </div>
    </div>
</div>

<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 
