<?php
if(!defined("ACCESS")) {
    header('Location: /');
    die('error: not access login'); 
    }

require_once('../inc/config.php');

if(isset($_POST[password])){
   
    if($_POST[password] == CP_ADMIN_PASSWORD ){
        $_SESSION[cp_id] = CP_ADMIN_PASSWORD;
        header('location: '.DOMAIN.'admin/cp.php');
    }else{
        $error = "Не верный пароль";
         
    }
}
?>
<!doctype html>
<html>
    <head>
        <link rel="stylesheet" href="<?=DOMAIN?>css/cp_style.css" type="text/css"/>
    </head>
    <body>
        <div class="cp-login">
            <h1>Вход в панель управления</h1>
    <form action="" method="post">
        <p> <label>Введите пароль:</label> </p>
        <p><input type="password" name="password" name="cp_access_password" /></p>
        <p><button class="button-grey-to-white">Авторизоваться</button> </p>
        <p id="status" class="<?=($error ? 'error' : '')?>"><?=($error ? $error : '')?></p>
    </form>
</div>
    </body>
</html>
