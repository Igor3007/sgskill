<div class="add-master-class">
  <div class="wrap-add-master">    
    <div class="left-bar">
        <div  class="foto">
            <img src="<?=$data['img']?>" />
        </div>
        <div class="button_upload">
            <input type="file" name="file" id="upload_img"  value="Выбрать фото" data-mid="7">
        </div>
    </div>
      
      
    
    <div class="right-bar">
        <p>
            <label>Заголовок:</label>
            <input type="text" placeholder="Заголовок" name="title" value="<?=$data['masterTitle']?>" class="name_wedding">
        </p>
        <p>
            <label>Стоимость:</label>
            <input type="text" placeholder="Стоимость" name="price" value="<?=$data['price']?>" class="name_wedding">
        </p>
        <p>
            <label>Дата и время мастер-класса:</label>
            <input type="text" placeholder="Дата" name="date_time" value="<?=$data['date']?>" class="date_master_class"><br />
            <input type="text" placeholder="Время" name="date_mc_time" value="<?=$data['mc_time']?>" class="maps_mc">
        </p>
        <p>
            <label>Место проведения:</label>
            <input type="text" placeholder="Город, улица" name="adress" value="<?=$data['adress']?>" class="name_wedding"><br />
            <input type="text" placeholder="Ссылка GoogleMaps" name="link_adress" value="<?=urldecode($data['adress_link'])?>" class="maps_mc">
        </p>
        <p>
            <label>Группа и Количество записавшихся:</label>
            <input type="text"  placeholder="Всего мест" value="<?=$data['group']?>" name="group" class="em"><br />
            <input type="text"  placeholder="Записалось" value="<?=$data['group_plus']?>" name="group_plus" class="maps_mc em">
        </p>
        <p>
            <label>Категория:</label>
            <select name="catid">
                <? while($cat = mysqli_fetch_assoc($catid)){
                    if($cat['id'] == $data['catidId']){
                        echo '<option value="'.$cat[id].'" selected="selected" >'.$cat[title].'</option>';
                    }else{
                        echo '<option value="'.$cat[id].'" >'.$cat[title].'</option>';
                    }
                } ?>
            </select>
        </p>
         
    </div>
  </div> 
    
    <div class="full_text">
        <p>
           <label>Краткое орисание:</label>
           <textarea id="pre_text" class="pre_text" name="pre_text"><?=$data['pre_text']?></textarea>    
        </p>
        
        <label>Полное описание:</label>
        <textarea id="full_text"><?=urldecode($data['text'])?></textarea>
    </div>
    
    <div class="save">
       <button class="btn-grey" data-id="<?=$data['masterId']?>" id="edit_mc">Сохранить изменения</button> 
    </div>
</div>

<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 
 
