<div class="top-nav-bar">
    <a href="./cp.php?view=5"><button class="btn-grey">Добавить</button></a>
    <a href="./cp.php?view=6"><button class="btn-grey">Категории</button></a>
</div>

 <? 
   /* $d = mysqli_fetch_all($query, MYSQLI_ASSOC);
    echo"<pre>";
              print_r($d);
    echo"</pre>";*/
    ?>

<div class="table-catid mc-table">
<table class="tg table-catid" style="width: 90%;">
  <tr>
    <th class="tg-031e">ID</th>
    <th class="tg-031e">Заголовок</th>
    <th class="tg-031e">Адрес</th>
    <th class="tg-031e">Дата проведения</th>
    <th class="tg-031e">Категория</th>
    <th class="tg-031e">Дата создания</th>
    <th class="tg-031e">Статус</th>
    <th class="tg-031e">Удалить</th>
  </tr>
   <? while($data = mysqli_fetch_row($query)): ?>
        <tr id="<?=$data[1]?>" class="item-cat">
          <td class="tg-031e table-id"><?=$data[1]?></td>
            <td class="tg-031e table-title"><span class="text-line" style ="max-width: 300px;"><a href="./cp.php?view=10&edit=<?=$data[1]?>"><?=$data[3]?></a></span></td>
          <td class="tg-031e table-title"><span class="text-line"><?=$data[7]?></span></td>
          <td class="tg-031e table-title"><span class="text-line"><?=setDates($data[4], array(true, false))?></span></td>
          <td class="tg-031e table-title"><?=$data[2]?></td>
          <td class="tg-031e table-title"><span class="text-line"><?=getDates($data[5])?></span></td>
            <td class="tg-031e table-title"><span class="text-line" style="max-width :70px"><?=$status[$data[8]]?></span></td>
          <td class="tg-031e table-id"><span class="delite del-catid-mc" data-id="<?=$data[1]?>" data-mid ="5"></span></td>
       </tr>
   <? endwhile ?> 
</table>
</div>