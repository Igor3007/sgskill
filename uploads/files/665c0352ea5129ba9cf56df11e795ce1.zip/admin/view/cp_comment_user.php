<div class="comments">
    <div class="tabs">
        <ul>
            <li class="name-tab <?=($_GET['view'] == 3 ? 'active' : '')?> " ><a href="./cp.php?view=3">Последние</a></li>
            <li class="name-tab <?=($_GET['view'] == 13 ? 'active' : '')?> "><a href="./cp.php?view=13">По статьям</a></li>
            <li class="name-tab <?=($_GET['view'] == 14 ? 'active' : '')?> "><a href="./cp.php?view=14">Все пользователи</a></li>
        </ul>
    </div>
    
    <div class="comment-list">
      <? while($data = mysqli_fetch_assoc($query)):?>     
        <div class="item-user parent-setting parent_del">
            <div class="avatar">
                <img src="<?=$data['avatar']?>" />
                <span class="setting"></span>
            </div>
            
            <div class="user-data">
                <?=$data['blackList'] ? '<p class="blist"><span class="cell-1">Черный список:</span><span class="cell-2" style="color:red;">Этот пользователь не может оставлять комментарии</span> </p>' : ''?>
                
                <p><span class="cell-1">Имя Фамилия:</span>
                   <span class="cell-2"><?=$data['first_name'].' '.$data['last_name']?></span>
                </p>
                    
                <p><span class="cell-1">Профиль:</span>
                   <span class="cell-2"><a href="<?=$data['link_profile']?>"><?=$data['link_profile']?></a></span>
                </p>
                
                <p><span class="cell-1">Зарегистророван:</span>
                   <span class="cell-2"><?=getDates($data['date'])?></span>
                </p>
                
                <p><span class="cell-1">Последний визит:</span>
                   <span class="cell-2"><?=getDates($data['date_update'])?></span>
                </p>
                
                <p><span class="cell-1">Через:</span>
                   <span class="cell-2"><?=$data['auth_id']?></span>
                </p>
                
                <div class="action">
                   <button class="btn-grey min del_user" data-id="<?=$data['id']?>" data-mid="16">Удалить</button>
                   <button class="btn-grey min ban_user" data-id="<?=$data['uid']?>" >В Черный список</button>
                   
                </div>
                
                
            </div>
        </div>
      <? endwhile ?>        
    </div>
    <?=$pg['button']?>
</div>