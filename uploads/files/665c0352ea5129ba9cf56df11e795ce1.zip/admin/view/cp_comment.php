<div class="comments">
    <div class="tabs">
        <ul>
            <li class="name-tab <?=($_GET['view'] == 3 ? 'active' : '')?> " ><a href="./cp.php?view=3">Последние</a></li>
            <li class="name-tab <?=($_GET['view'] == 13 ? 'active' : '')?> "><a href="./cp.php?view=13">По статьям</a></li>
            <li class="name-tab <?=($_GET['view'] == 14 ? 'active' : '')?> "><a href="./cp.php?view=14">Все пользователи</a></li>
        </ul>
    </div>
    
    <div class="comment-list">
      <? while($data = mysqli_fetch_assoc($query)):?>     
        <div class="item-comment parent_del">
            <div class="avatar">
                <img src="<?=$data['avatar']?>" />
            </div>
            <div class="text">
                <h5><a href="./cp.php?view=15&user=<?=$data['uid']?>"><?=$data['user']?></a> <span class="delite delite_comm" data-id="<?=$data['commID']?>" data-mid="14" ></span> </h5>
                <p class = "comm"><?=$data['text_comment']?></p>
                <p class="time-comment">
                    <?=getDates($data['date_comment'])?> на странице 
                    <a href = "<?DOMAIN?>/lesson/<?=$data['masterID']?>.html" target="_blank" ><span class="mc-title"><?=$data['masterTitle']?></span></a>
                </p>
            </div>
        </div>
     <? endwhile ?>        
    </div>
     
</div>