<? $html ='
<div class="wrap-attach-video">
    <div class="preview-video">
        <img id="img_video" src="../../img/icons/default_img.jpg" />
        <input type="file" data-mid="7.2" data-id="3" name="file" value="Выбрать" class="upload_img">
    </div>
    <div class="link-video">
        <label>Ссылка на видео</label>
        <input type="text" name="link_video" placeholder="YouTube, Vimeo"/>
    </div>
    
</div>
<div class="modal-footer">
        <button class="btn-grey" id="add-video">Добавить</button>
</div>';