<div class="top-nav-bar">
    <a href="./cp.php?view=5"><button class="btn-grey">Добавить</button></a>
    <a href="./cp.php?view=6"><button class="btn-grey">Категории</button></a>
</div>

<div class="table-catid mc-table">
<table class="tg table-catid" style="width: 90%;">
  <tr>
    <th class="tg-031e">ID</th>
    <th class="tg-031e">Имя Фамилия</th>
    <th class="tg-031e">Email</th>
    <th class="tg-031e">Категория</th>
    <th class="tg-031e">Дата создания</th>
    <th class="tg-031e">Статус</th>
    <th class="tg-031e">Удалить</th>
  </tr>
   <? while($data = mysqli_fetch_assoc($query)): ?>
        <tr id="<?=$data['masterID']?>" class="item-cat">
          <td class="tg-031e table-id"><?=$data['masterID']?></td>
          <td class="tg-031e table-title"><span class="text-line" style ="max-width: 300px;"><a href="./cp.php?view=10&edit=<?=$data['masterID']?>"><?=$data['title']?></a></span></td>
          <td class="tg-031e table-id"><?=$data['email']?></td> 
          <td class="tg-031e  "><?=$data['catidTitle']?></td>
          <td class="tg-031e  "><span class="text-line"><?=getDates($data['date_create'])?></span></td>
          <td class="tg-031e  "><span class="text-line" style="max-width :70px"><?=$status[$data['status']]?></span></td>
          <td class="tg-031e table-id"><span class="delite del-catid-mc" data-id="<?=$data['masterID']?>" data-mid ="5"></span></td>
       </tr>
   <? endwhile ?> 
</table>
<?=$pg['button']?>
</div>