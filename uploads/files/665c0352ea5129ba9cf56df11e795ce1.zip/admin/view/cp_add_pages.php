<div class="pages">
  <div class="about">
    <div class="foto-autor foto">
        <img alt="" src="../../img/icons/default_img2.jpg">
        <input type="file" name="file" class="upload_img" data-mid="7" />
    </div>
    
    <div class="detalis">
        <p>
            <label>Название</label>
            <input type="text" name="title" placeholder="Название страницы" />
        </p>
        <p>
            <label>Пароль доступа</label>
            <input type="text" name="password" placeholder="Пароль страницы(если требуется)" />
        </p>
        <p>
            <label>Категория</label>
            <select name="cat">
                <option value ="2">Cтатьи</option>
                <option value ="1">Cистемные</option>
                <option value ="0">Cкрытые</option>
            </select>
        </p>
        <p>
            <label>Keywords</label>
            <textarea   name="keywords" placeholder="Ключевые слова"></textarea>
        </p>
    </div>
    
  </div>
   <div class="descr">
        <textarea id = "full_text" ></textarea>
   </div>
    
   <div class="save">
       <button class="btn-grey" id="add_page" data-id="<?=$data['id']?>">Добавить</button>
   </div>
    
</div>

<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 