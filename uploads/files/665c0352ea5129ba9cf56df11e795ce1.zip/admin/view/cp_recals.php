<div class="top-nav-bar">
    <a href="./cp.php?view=11"><button class="btn-grey">Новый отзыв</button></a>
</div>



<div class="table-catid recal-table">
<table class="tg table-catid" style="width: 90%;">
  <tr>
    <th class="tg-031e">ID</th>
    <th class="tg-031e">Имя Фамилия</th>
    <th class="tg-031e">Текст</th>
    <th class="tg-031e">Размещение</th>
    <th class="tg-031e">Удалить</th>
  </tr>
  
    <? while($data = mysqli_fetch_assoc($query)): ?>
        <tr id="<?=$data['id']?>" class="item-cat">
          <td class="tg-031e table-id"><?=$data['id']?></td>
            <td class="tg-031e table-title"><span class="text-line" style ="max-width: 300px;"><a href="./cp.php?view=12&edit=<?=$data['id']?>"><?=$data['title']?></a></span></td>
          <td class="tg-031e table-title"><?=stripslashes($data['text'])?></td>
          <td class="tg-031e table-id"><span class="text-line"><?=$page[$data['loc']]?></span></td>
          <td class="tg-031e table-id"><span class="delite del-catid-mc" data-id="<?=$data['id']?>" data-mid ="13"></span></td>
       </tr>
   <? endwhile ?> 
    
    
</table>
</div>