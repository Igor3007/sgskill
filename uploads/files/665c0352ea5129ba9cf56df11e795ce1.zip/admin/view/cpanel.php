<? if(!isset($_SESSION[cp_id]) or !defined("ACCESS")) {
    header('Location: /');
    die('error: not access cp'); 
    }
?>
<!doctype html>
<html>
    <head>
        <link rel="stylesheet" href="<?=DOMAIN?>css/cp_style.css" type="text/css" >
        <link rel="stylesheet" href="<?=DOMAIN?>css/lib/jquery.datetimepicker.css" type="text/css" >
        
        <script type="text/javascript" src="<?=DOMAIN?>js/lib/jquery-1.11.3.js"></script>
        <script type="text/javascript" src="<?=DOMAIN?>js/lib/jquery.datetimepicker.full.min.js"></script>
        <script type="text/javascript" src="<?=DOMAIN?>js/lib/simpleUpload.min.js"></script>
        <script type="text/javascript" src="<?=DOMAIN?>js/lib/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?=DOMAIN?>admin/tiny_mce/tiny_mce.js"></script>
        <script type="text/javascript" src="<?=DOMAIN?>admin/core/main.js"></script>
        
        <title><?=($cp_view[title])?></title>
    </head>
    <body>
        <div class="main">
            <header>
                <span class="logo">Панель управления</span>
            </header>
            <nav>
                <ul>
                    <li><a href="?view=2">Страницы</a><span class="<?=(2 == $cp_view[act_menu] ? 'active' : '')?>"></span></li>
                    <li><a href="?view=7">Галереи</a><span class="<?=(5 == $cp_view[act_menu] ? 'active' : '')?>"></span></li>
                    <li><a href="?view=1">Специалисты</a><span class="<?=(1 == $cp_view[act_menu] ? 'active' : '')?>"></span></li>
                    <li><a href="?view=order">Заказы</a><span class="<?=('order' == $cp_view[act_menu] ? 'active' : '')?>"></span></li>
                </ul>
            </nav>
            <main>
                <div id="status"></div>
                <h1><?=$cp_view[title]?></h1>
                
                <div class = "cp_content">
                   <?php require_once('view/'.$cp_view[view].'.php'); ?>
                </div>
            </main>
            <footer></footer>
        </div>
    </body>
    <div id="modal" class="modal-window">
        <div class="modal-window-content">
            <div class="modal-header"><span>name</span> <i class="close-modal">X</i></div>
            <div id="modal-progress" class="progress"> <div class="indeterminate"></div> </div>
            <div class="modal-wrap-content">
                 <center>Загрузка...</center>
            </div>
        </div>
    </div>
</html>