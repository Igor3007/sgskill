<div class="top-nav-bar">
    <a href="./cp.php?view=8"><button class="btn-grey">Новая галерея</button></a>
</div>

<div class="table-gallery">
<table class="tg" style="width: 90%;">
  <thead>
      <tr>
        <th class="tg-031e">ID</th>
        <th class="tg-031e">Название галереи</th>
        <th class="tg-031e">Размещение</th>
        <th class="tg-031e">Статус</th>
        <th class="tg-031e">Удалить</th>
      </tr>
  </thead>  
  <tbody>
      <? while($data = mysqli_fetch_assoc($query)): ?>
            <tr id="<?=$data['id']?>" class="table-tr">
              <td class="tg-031e table-id"><?=$data['id']?></td>
                <td class="tg-031e table-title"><span class="text-line" style ="max-width: 300px;"><a href="./cp.php?view=9&edit=<?=$data['id']?>"><?=$data['title']?></a></span></td>
              <td class="tg-031e table-title"><span class="text-line"><?=$page[$data['loc']]?></span></td>
              <td class="tg-031e table-id"><span class="text-line"><?=$data['status']?></span></td>
              <td class="tg-031e table-id"><span class="delite del-catid-mc" data-id="<?=$data['id']?>" data-mid ="6"></span></td>
           </tr>
       <? endwhile ?> 
  </tbody>
  
</table>
</div>