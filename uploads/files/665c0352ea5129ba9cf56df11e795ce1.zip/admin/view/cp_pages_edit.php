<div class="pages">
  <div class="about">
     
        
    <div class="foto-autor foto">
        <img alt="" src="<?=(empty($data['img'])? '/img/icons/default_img2.jpg':$data['img'])?>"  title='<?=$data['img']?>'>
        <span id="delete-foto" >X Удалить фото</span>
        <input type="file" name="file" class="upload_img" data-mid="7" />
    </div>
      
     
      
    <div class="detalis">
        <p>
            <label>Название</label>
            <input type="text" name="title" value="<?=$data['title']?>" />
        </p>
        <p>
            <label>Пароль</label>
            <input type="text" name="password" value="<?=$data['password']?>" />
        </p>
        <p>
            <label>Категория</label>
            <select name="cat">
                <?=selectActive($cat_page, $data['cat'])?>
            </select>
        </p>
         <p>
            <label>Keywords</label>
            <textarea name="keywords" placeholder="Ключевые слова"><?=$data['keywords']?></textarea>
        </p>
    </div>
    
  </div>
   <div class="descr">
        <textarea id = "full_text" ><?=$data['text']?></textarea>
   </div>
    
   <div class="save">
       <button class="btn-grey" id="edit_page" data-id="<?=$data['id']?>">Сохранить изменения</button>
   </div>
    
</div>
<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 