<div class="top-nav-bar">
    <a href="./cp.php?view=add"><button class="btn-grey">Добавить</button></a>
     
</div>
<div class="pages pages-table">
<table class="tg table-page" style="width: 90%;">
  <thead>
      <tr>
        <th class="tg-031e">ID</th>
        <th class="tg-031e">Название сраницы</th>
        <th class="tg-031e">Категория</th>
        <th class="tg-031e">Описание</th>
        <th class="tg-031e">Удалить</th>
      </tr>
  </thead>  
  <tbody>
        <? while($data = mysqli_fetch_assoc($query)): ?>
        <tr id="<?=$data['id']?>" class="item-page">
            <td><?=$data['id']?></td>
            <td><h5><a href="./cp.php?view=16&edit=<?=$data['id']?>"><?=$data['title']?></a></h5></td>
            <td><?=$cat_page[$data[cat]]?></td>
            <td><?=crop_str(htmlspecialchars_decode($data['text']), 100)?></td>
            <td><span data-mid="5.1" data-id="<?=$data['id']?>" class="delite"></span></td>
        </tr>
   <? endwhile ?> 
  </tbody>
  
</table>
 
</div>