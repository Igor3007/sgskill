<div class="comments">
    <div class="tabs">
        <ul>
            <li class="name-tab <?=($_GET['view'] == 3 ? 'active' : '')?> " ><a href="./cp.php?view=3">Последние</a></li>
            <li class="name-tab <?=($_GET['view'] == 13 ? 'active' : '')?> "><a href="./cp.php?view=13">По статьям</a></li>
            <li class="name-tab <?=($_GET['view'] == 14 ? 'active' : '')?> "><a href="./cp.php?view=14">Все пользователи</a></li>
        </ul>
    </div>
    <div class="comment-master">
      <? while($data = mysqli_fetch_assoc($query)): ?>
        <div class="item-article">
            <h5><?=$data['title']?></h5>
            <div class="comment">
                <div class="item-comment">
                    <?
                     $img = getComments($data['masterID']);
                     while($imgs = mysqli_fetch_assoc($img)): ?>
                     <div class="item-comment parent_del">
                            <div class="avatar">
                                <img src="<?=$imgs['avatar']?>" />
                            </div>
                        <div class="text">
                            <h5><a href="./cp.php?view=15&user=<?=$imgs['uid']?>"><?=$imgs['user']?></a> <span class="delite delite_comm" data-id="<?=$imgs['id']?>" data-mid="14" ></span> </h5>
                            <p class = "comm"><?=$imgs['text_comment']?></p>
                            <p class="time-comment"> <?=getDates($imgs['date_comment'])?></p>
                        </div>
                        </div>
                    <? endwhile?>
                </div>
            </div>
        </div>
    <? endwhile ?>
    </div>
    <?=$pg['button']?>
</div>