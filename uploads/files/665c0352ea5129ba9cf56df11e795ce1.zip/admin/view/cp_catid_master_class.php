<div class="add-catid">
    <label class="label-line" >Добавить новую категорию</label>
    <input type="text" placeholder="Название категории" id='catid_name'/>
    <button class="btn-grey" id="add_cp_catid">Добавить</button>
</div>

<div class="table-catid">
<table class="tg table-catid">
  <tr>
    <th class="tg-031e">ID</th>
    <th class="tg-031e">Название категории</th>
    <th class="tg-031e">Удалить</th>
  </tr>
   <? while($data = mysqli_fetch_assoc($query)): ?>
        <tr class="item-cat" id="<?=$data[id]?>">
          <td class="tg-031e table-id"><?=$data[id]?></td>
          <td class="tg-031e table-title"><?=$data[title]?></td>
          <td class="tg-031e table-id"><span class="delite del-catid-mc" data-id="<?=$data[id]?>" data-mid ="4"></span></td>
       </tr>
   <? endwhile ?>  
</table>
</div>