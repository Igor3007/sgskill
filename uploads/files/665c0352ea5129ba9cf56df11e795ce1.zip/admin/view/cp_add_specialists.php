<div class="add-master-class">
  <div class="wrap-add-master">    
    <div class="left-bar">
        <div  class="foto specialist">
            <img src="<?=DOMAIN?>img/icons/default_img.jpg" />
        </div>
        <div class="button_upload">
            <input type="file" name="file" class="upload_img"  value="Выбрать фото" data-mid="7">
        </div>
    </div>
    
    <div class="right-bar">
        <p>
            <label>Имя Фамилия:</label>
            <input type="text" value="" placeholder="Имя Фамилия" name="title" class="em">
        </p>
        
        <p>
            <label>E-mail:</label>
            <input type="text" value="" placeholder="E-mail специалиста" name="email" class="em">
        </p>
        
        <p>
            <label>Категория:</label>
             <select name="catid">
                <? while($cat = mysqli_fetch_assoc($catid)){
                    if($cat['id'] == $data['catidId']){
                        echo '<option value="'.$cat[id].'" selected="selected" >'.$cat[title].'</option>';
                    }else{
                        echo '<option value="'.$cat[id].'" >'.$cat[title].'</option>';
                    }
                } ?>
            </select>
        </p>
        
        <p>
            <label>Статус:</label>
            <select name="status">
                 <?=selectActive($status, 1)?>
            </select>
        </p>
    </div>
  </div> 
    
    <div class="full_text">
        <label>Полное описание:</label>
        <textarea id="full_text"></textarea>
    </div>
    
    <div class="save">
       <button class="btn-grey" id="send_mc">Добавить</button> 
    </div>
</div>

<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 
 
