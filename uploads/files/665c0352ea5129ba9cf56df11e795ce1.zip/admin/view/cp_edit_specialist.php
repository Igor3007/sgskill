<div class="add-master-class">
  <div class="wrap-add-master">    
    <div class="left-bar">
        <div  class="foto specialist">
            <img src="<?=$data['img']?>" />
        </div>
        <div class="button_upload">
            <input type="file" name="file" class="upload_img"  value="Выбрать фото" data-mid="7">
        </div>
    </div>
      
      
    
    <div class="right-bar">
        <p>
            <label>Имя Фамилия:</label>
            <input type="text" placeholder="Заголовок" name="title" value="<?=$data['masterTitle']?>" class="name_wedding">
        </p>
        <p>
            <label>Email:</label>
            <input type="text" placeholder="Email" name="email" value="<?=$data['email']?>" class="name_wedding">
        </p>
        
        <p>
            <label>Категория:</label>
            <select name="catid">
                <? while($cat = mysqli_fetch_assoc($catid)){
                    if($cat['id'] == $data['catidId']){
                        echo '<option value="'.$cat[id].'" selected="selected" >'.$cat[title].'</option>';
                    }else{
                        echo '<option value="'.$cat[id].'" >'.$cat[title].'</option>';
                    }
                } ?>
            </select>
        </p>
        
        <p>
            <label>Статус:</label>
            <select name="status">
                 <?=selectActive($status, $data['status'])?>
            </select>
        </p>
         
    </div>
  </div> 
    
    <div class="full_text">
        <label>Полное описание:</label>
        <textarea id="full_text"><?=urldecode($data['text'])?></textarea>
    </div>
    
    <div class="save">
       <button class="btn-grey" data-id="<?=$data['masterId']?>" id="edit_mc">Сохранить изменения</button> 
    </div>
</div>

<div class="overlay_uploader">
    <div class="box-upload">
        <div class="header-uloader">
            <h6>Загрузка файла на сервер</h6>
        </div>
        
        <div class="main-uloader">
            <h5>Maxim fadeev - breath the line</h5>
            <div class="progressBox">
               <div class="progressBar"></div>
            </div>
        </div>
        
        <div class="button-upload">
            <button class="btn-grey">отмена</button>
        </div>
    </div>
</div> 
 
