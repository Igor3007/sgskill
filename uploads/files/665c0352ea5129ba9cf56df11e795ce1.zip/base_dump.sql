
-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 26 2016 г., 16:07
-- Версия сервера: 10.0.20-MariaDB
-- Версия PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `u547230309_wed`
--

-- --------------------------------------------------------

--
-- Структура таблицы `sg_calid_master_class`
--

CREATE TABLE IF NOT EXISTS `sg_calid_master_class` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `state` int(1) NOT NULL DEFAULT '1',
  `id_sort` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sg_gallery`
--

CREATE TABLE IF NOT EXISTS `sg_gallery` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `loc` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `id_sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sg_gallery_img`
--

CREATE TABLE IF NOT EXISTS `sg_gallery_img` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_sort` int(10) NOT NULL,
  `img` varchar(255) NOT NULL,
  `g_id` int(5) NOT NULL,
  `img_max` varchar(255) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sg_master_class`
--

CREATE TABLE IF NOT EXISTS `sg_master_class` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_sort` int(10) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mc_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `catid` int(3) NOT NULL,
  `adress_link` text COLLATE utf8_unicode_ci NOT NULL,
  `adress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pre_text` text COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `group_plus` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sg_orders`
--

CREATE TABLE IF NOT EXISTS `sg_orders` (
  `id_order` int(10) NOT NULL AUTO_INCREMENT,
  `user_data` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_select_wedding` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tour_country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tour_params` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tour_cat_hotel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tour_start_date` date NOT NULL,
  `tour_end_date` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tour_type_food` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `type_order` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `type_notification` int(1) NOT NULL DEFAULT '3',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_note` text COLLATE utf8_unicode_ci NOT NULL,
  `date_take` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_complete` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sg_pages`
--

CREATE TABLE IF NOT EXISTS `sg_pages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `text` mediumtext NOT NULL,
  `img` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `id_sort` int(11) NOT NULL,
  `cat` int(5) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `sg_pages`
--

INSERT INTO `sg_pages` (`id`, `text`, `img`, `title`, `id_sort`, `cat`, `password`, `date`, `keywords`) VALUES
(14, '&lt;p&gt;ewfewfewf&lt;/p&gt;', '/img/images/mc_571e960ba7c1c.jpg', 'Статья 1', 0, 2, '', '2016-04-25 22:11:34', ''),
(15, '&lt;h1 style=&quot;text-align: center;&quot;&gt;Наши партнеры&lt;/h1&gt;', '', 'Партнеры', 0, 1, '', '2016-04-25 22:13:56', ''),
(17, '&lt;p&gt;Контакты&lt;/p&gt;', '', 'Контакты', 0, 1, '', '2016-04-25 22:16:56', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
