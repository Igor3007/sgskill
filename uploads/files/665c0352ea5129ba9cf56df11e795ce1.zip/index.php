<?php session_start();
$skins = $_GET[v];
require_once('./core/core.php');
?>
<!doctype html>
 <html>
   <head>
    <title><?=$view['title']?> - Slava Grebenkin</title>
    <meta name="viewport" content="width=1024">
    <meta http-equiv="content-type" content="text/html" charset="utf-8" />
	<meta name="keywords" content="<?=$view['keywords']?>" />
	<meta name="description" content="<?=$view['desc']?>" />
    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    
    <link href="<?=DOMAIN?>/css/lib/magnific-popup.css" rel="stylesheet" type="text/css">
	<link href="<?=DOMAIN?>/css/lib/font-awesome.css" rel="stylesheet" type="text/css">  
	<link href="<?=DOMAIN?>/css/animate.css" rel="stylesheet" type="text/css">  
	<link href="<?=DOMAIN?>/css/lib/jquery.datetimepicker.css" rel="stylesheet" type="text/css">  
	<link href="<?=DOMAIN?>/css/style.css?v=121" rel="stylesheet" type="text/css">
	<link href="<?=DOMAIN?>/css/media-queres.css" rel="stylesheet" type="text/css">
	
	<script src="<?=DOMAIN?>/js/lib/jquery-1.11.3.js" type="text/javascript"></script>
	<script src="<?=DOMAIN?>/js/lib/magnific.js" type="text/javascript"></script>
	<script src="<?=DOMAIN?>/js/lib/jquery.datetimepicker.full.min.js" type="text/javascript"></script>
	<script src="<?=DOMAIN?>/js/main.js" type="text/javascript"></script>
	
   </head>
   
   <body>
       <header>
	        <nav>
	            <? include_once('./skins/top-menu.php')?>
	        </nav>
	    </header>
     <div class = "main">
	       <? require_once('./skins/'.$view['skin'].'.php'); ?> 
	 </div>
        <footer>
                <? include_once('./skins/footer.php');?>
        </footer>       
   </body>
 </html>